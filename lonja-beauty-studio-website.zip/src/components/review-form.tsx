"use client";

import { useState } from "react";

export function ReviewForm({ technicians }: { technicians: string[] }) {
  const [rating, setRating] = useState(5);
  const [name, setName] = useState("");
  const [technician, setTechnician] = useState("");
  const [service, setService] = useState("Acrylic nails");
  const [body, setBody] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setState("sending");
    setError(null);
    try {
      const response = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          authorName: name,
          rating,
          technicianName: technician || null,
          serviceTag: service,
          body,
        }),
      });
      const data = (await response.json()) as { ok: boolean; error?: string };
      if (!data.ok) {
        setError(data.error ?? "Could not save your review.");
        setState("error");
        return;
      }
      setState("done");
      setBody("");
      setName("");
    } catch {
      setError("Network error — please try again.");
      setState("error");
    }
  }

  if (state === "done") {
    return (
      <div className="card p-8 text-center">
        <span className="text-4xl">🙏</span>
        <h3 className="mt-3 font-display text-2xl font-bold text-plum">Thank you!</h3>
        <p className="mx-auto mt-2 max-w-md text-sm text-plum-soft">
          Your review has been sent to the studio for approval. We read every single one and use them
          to coach the team.
        </p>
        <button type="button" onClick={() => setState("idle")} className="btn btn-ghost mt-5">
          Write another
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="card p-6 sm:p-8">
      <span className="label">How was your visit?</span>
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((value) => (
          <button
            key={value}
            type="button"
            aria-label={`${value} star`}
            onClick={() => setRating(value)}
            className={`text-3xl leading-none transition ${
              value <= rating ? "text-gold" : "text-plum/20 hover:text-gold/60"
            }`}
          >
            ★
          </button>
        ))}
        <span className="ml-2 text-sm text-plum-soft">{rating}/5</span>
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="review-name">
            Your name *
          </label>
          <input
            id="review-name"
            className="field"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="e.g. Nombuso M."
          />
        </div>
        <div>
          <label className="label" htmlFor="review-service">
            Service
          </label>
          <select
            id="review-service"
            className="field"
            value={service}
            onChange={(event) => setService(event.target.value)}
          >
            {[
              "Acrylic nails",
              "Gel nails",
              "Polygel",
              "Cat eye",
              "Ombre",
              "Eyelash extensions",
              "Braids",
              "Blow out",
              "Haircut",
              "Other",
            ].map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="label" htmlFor="review-tech">
            Who looked after you?
          </label>
          <select
            id="review-tech"
            className="field"
            value={technician}
            onChange={(event) => setTechnician(event.target.value)}
          >
            <option value="">Not sure / someone else</option>
            {technicians.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="label" htmlFor="review-body">
            Your review *
          </label>
          <textarea
            id="review-body"
            rows={4}
            className="field"
            value={body}
            onChange={(event) => setBody(event.target.value)}
            placeholder="Tell us about the service, the tech, and how your nails turned out…"
          />
        </div>
      </div>

      {error ? (
        <p className="mt-4 rounded-xl bg-rose-50 p-3 text-sm text-rose-700 ring-1 ring-rose-200">
          {error}
        </p>
      ) : null}

      <button
        type="submit"
        disabled={state === "sending" || name.trim().length < 2 || body.trim().length < 10}
        className={`btn btn-primary mt-5 ${
          state === "sending" || name.trim().length < 2 || body.trim().length < 10
            ? "cursor-not-allowed opacity-50"
            : ""
        }`}
      >
        {state === "sending" ? "Sending…" : "Submit review"}
      </button>
      <p className="mt-3 text-xs text-plum-soft/70">
        Reviews are moderated before they appear on the site. You can also leave a review directly on
        Google.
      </p>
    </form>
  );
}
