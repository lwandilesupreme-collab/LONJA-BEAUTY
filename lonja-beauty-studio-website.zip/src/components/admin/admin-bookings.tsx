"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";

import type { Booking } from "@/db/schema";
import { STATUS_LABEL, STATUS_STYLE, prettyDate, prettyTime } from "@/lib/booking";
import { formatMoney } from "@/lib/site";

const ACTIONS: { status: string; label: string }[] = [
  { status: "confirmed", label: "Confirm" },
  { status: "completed", label: "Complete" },
  { status: "cancelled", label: "Cancel" },
  { status: "no_show", label: "No show" },
];

export function AdminBookings({ bookings }: { bookings: Booking[] }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [busyId, setBusyId] = useState<number | null>(null);
  const [query, setQuery] = useState("");

  async function setStatus(id: number, status: string) {
    setBusyId(id);
    try {
      await fetch(`/api/admin/bookings/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      startTransition(() => router.refresh());
    } finally {
      setBusyId(null);
    }
  }

  async function remove(id: number) {
    setBusyId(id);
    try {
      await fetch(`/api/admin/bookings/${id}`, { method: "DELETE" });
      startTransition(() => router.refresh());
    } finally {
      setBusyId(null);
    }
  }

  const filtered = bookings.filter((booking) =>
    `${booking.reference} ${booking.customerName} ${booking.customerPhone} ${booking.serviceName} ${booking.bookingDate}`
      .toLowerCase()
      .includes(query.toLowerCase()),
  );

  return (
    <div>
      <input
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Search reference, name, number, service…"
        className="field mb-4"
      />

      {pending && !busyId ? (
        <p className="mb-3 text-xs text-plum-soft">Refreshing…</p>
      ) : null}

      <div className="space-y-3">
        {filtered.map((booking) => (
          <article key={booking.id} className="card p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-display text-lg font-bold text-plum">
                  {booking.serviceName}
                  <span className="ml-2 font-sans text-xs font-semibold text-plum-soft">
                    {booking.reference}
                  </span>
                </p>
                <p className="text-sm text-plum-soft">
                  {booking.customerName} · {booking.customerPhone}
                </p>
                <p className="mt-1 text-xs text-plum-soft/80">
                  {prettyDate(booking.bookingDate)} at {prettyTime(booking.bookingTime)} ·{" "}
                  {booking.durationMinutes} min · {formatMoney(booking.totalCents)}
                </p>
                {booking.technicianName ? (
                  <p className="text-xs text-plum-soft/80">Tech: {booking.technicianName}</p>
                ) : null}
                {booking.notes ? (
                  <p className="mt-2 rounded-lg bg-blush/70 p-2 text-xs text-plum-soft">
                    “{booking.notes}”
                  </p>
                ) : null}
              </div>

              <div className="text-right">
                <span
                  className={`inline-block rounded-full px-3 py-1 text-[0.7rem] font-semibold ring-1 ${
                    STATUS_STYLE[booking.status] ?? "bg-stone-100 text-stone-700 ring-stone-200"
                  }`}
                >
                  {STATUS_LABEL[booking.status] ?? booking.status}
                </span>
                <div className="mt-3 flex flex-wrap justify-end gap-1.5">
                  {ACTIONS.filter((action) => action.status !== booking.status).map((action) => (
                    <button
                      key={action.status}
                      type="button"
                      disabled={busyId === booking.id}
                      onClick={() => setStatus(booking.id, action.status)}
                      className="rounded-full bg-plum/8 px-2.5 py-1 text-[0.7rem] font-semibold text-plum transition hover:bg-plum hover:text-cream disabled:opacity-40"
                    >
                      {action.label}
                    </button>
                  ))}
                  <a
                    href={`https://wa.me/${booking.customerPhone.replace(/\D/g, "").replace(/^0/, "27")}?text=${encodeURIComponent(
                      `Hi ${booking.customerName}, it's Lonja Beauty Studio Fourways about your ${booking.serviceName} booking ${booking.reference}.`,
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-full bg-emerald-100 px-2.5 py-1 text-[0.7rem] font-semibold text-emerald-800 hover:bg-emerald-200"
                  >
                    WhatsApp
                  </a>
                  <button
                    type="button"
                    disabled={busyId === booking.id}
                    onClick={() => remove(booking.id)}
                    className="rounded-full bg-rose-100 px-2.5 py-1 text-[0.7rem] font-semibold text-rose-700 hover:bg-rose-200 disabled:opacity-40"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </article>
        ))}

        {!filtered.length ? (
          <p className="card p-8 text-center text-sm text-plum-soft">
            No bookings match that search.
          </p>
        ) : null}
      </div>
    </div>
  );
}
