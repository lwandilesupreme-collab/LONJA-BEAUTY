"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function AdminLogin() {
  const router = useRouter();
  const [passcode, setPasscode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ passcode }),
      });
      const data = (await response.json()) as { ok: boolean; error?: string };
      if (!data.ok) {
        setError(data.error ?? "Login failed");
        return;
      }
      router.refresh();
    } catch {
      setError("Network error");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid min-h-screen place-items-center bg-plum px-5">
      <form onSubmit={submit} className="w-full max-w-sm rounded-3xl bg-cream p-8 shadow-2xl">
        <div className="flex items-center gap-3">
          <span className="grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-plum to-rose-dark font-display text-xl font-bold text-cream">
            L
          </span>
          <div>
            <p className="font-display text-2xl font-bold text-plum">Studio Admin</p>
            <p className="text-[0.65rem] uppercase tracking-[0.25em] text-rose-dark">Fourways</p>
          </div>
        </div>

        <label className="label mt-7" htmlFor="passcode">
          Passcode
        </label>
        <input
          id="passcode"
          type="password"
          className="field"
          value={passcode}
          onChange={(event) => setPasscode(event.target.value)}
          placeholder="••••••••"
          autoFocus
        />

        {error ? (
          <p className="mt-3 rounded-lg bg-rose-50 p-2.5 text-xs text-rose-700 ring-1 ring-rose-200">
            {error}
          </p>
        ) : null}

        <button
          type="submit"
          disabled={loading || !passcode}
          className={`btn btn-primary mt-5 w-full ${loading || !passcode ? "opacity-50" : ""}`}
        >
          {loading ? "Checking…" : "Enter dashboard"}
        </button>

        <p className="mt-4 text-center text-[0.7rem] text-plum-soft/60">
          Default passcode is <code className="font-mono">lonja2026</code> — override it with the
          <code className="mx-1 font-mono">ADMIN_PASSCODE</code> env var.
        </p>
      </form>
    </div>
  );
}
