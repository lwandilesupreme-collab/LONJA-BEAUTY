"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

import type { Message, Review } from "@/db/schema";
import { STATUS_STYLE } from "@/lib/booking";

export function AdminReviews({ reviews }: { reviews: Review[] }) {
  const router = useRouter();
  const [filter, setFilter] = useState<"pending" | "all">("pending");

  const visible = reviews.filter((review) => (filter === "pending" ? !review.isApproved : true));

  async function patch(id: number, payload: Record<string, unknown>) {
    await fetch(`/api/admin/reviews/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    router.refresh();
  }

  async function remove(id: number) {
    await fetch(`/api/admin/reviews/${id}`, { method: "DELETE" });
    router.refresh();
  }

  return (
    <div>
      <div className="mb-4 flex gap-2">
        {(["pending", "all"] as const).map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => setFilter(option)}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold capitalize ${
              filter === option ? "bg-plum text-cream" : "bg-plum/8 text-plum"
            }`}
          >
            {option === "pending" ? "Awaiting approval" : "All reviews"}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {visible.map((review) => (
          <article key={review.id} className="card p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <p className="font-semibold text-plum">
                  {review.authorName}{" "}
                  <span className="text-gold">{"★".repeat(review.rating)}</span>
                  <span
                    className={`ml-2 rounded-full px-2 py-0.5 text-[0.65rem] font-semibold ring-1 ${
                      STATUS_STYLE[
                        review.isApproved ? "confirmed" : "pending"
                      ] ?? "bg-stone-100 text-stone-700 ring-stone-200"
                    }`}
                  >
                    {review.isApproved ? "Published" : "Pending"}
                  </span>
                </p>
                <p className="text-xs text-plum-soft">
                  {review.serviceTag ?? "—"} · {review.technicianName ?? "no tech"} ·{" "}
                  {review.source}
                </p>
                <p className="mt-2 text-sm leading-relaxed text-plum-soft">{review.body}</p>
                {review.ownerReply ? (
                  <p className="mt-2 rounded-lg bg-blush/70 p-2 text-xs text-plum-soft">
                    <strong>Owner replied:</strong> {review.ownerReply}
                  </p>
                ) : null}
              </div>
              <div className="flex shrink-0 flex-col gap-1.5">
                {review.isApproved ? (
                  <button
                    type="button"
                    onClick={() => patch(review.id, { isApproved: false })}
                    className="rounded-full bg-plum/8 px-3 py-1 text-[0.7rem] font-semibold text-plum hover:bg-plum hover:text-cream"
                  >
                    Unpublish
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => patch(review.id, { isApproved: true })}
                    className="rounded-full bg-emerald-100 px-3 py-1 text-[0.7rem] font-semibold text-emerald-800 hover:bg-emerald-200"
                  >
                    Approve
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => remove(review.id)}
                  className="rounded-full bg-rose-100 px-3 py-1 text-[0.7rem] font-semibold text-rose-700 hover:bg-rose-200"
                >
                  Delete
                </button>
              </div>
            </div>
          </article>
        ))}
        {!visible.length ? (
          <p className="card p-8 text-center text-sm text-plum-soft">Nothing here right now. ✨</p>
        ) : null}
      </div>
    </div>
  );
}

export function AdminMessages({ messages }: { messages: Message[] }) {
  return (
    <div className="space-y-3">
      {messages.map((message) => (
        <article key={message.id} className="card p-4">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <p className="font-semibold text-plum">
              {message.name}
              {message.subject ? (
                <span className="ml-2 text-xs font-normal text-plum-soft">{message.subject}</span>
              ) : null}
            </p>
            <p className="text-xs text-plum-soft/70">
              {new Date(message.createdAt).toLocaleString("en-ZA")}
            </p>
          </div>
          <p className="mt-1 text-xs text-plum-soft">
            {message.phone ? `${message.phone} · ` : ""}
            {message.email ?? "no email"}
          </p>
          <p className="mt-2 text-sm leading-relaxed text-plum-soft">{message.body}</p>
          {message.phone ? (
            <a
              href={`https://wa.me/${message.phone.replace(/\D/g, "").replace(/^0/, "27")}`}
              target="_blank"
              rel="noreferrer"
              className="mt-3 inline-block rounded-full bg-emerald-100 px-3 py-1 text-[0.7rem] font-semibold text-emerald-800 hover:bg-emerald-200"
            >
              Reply on WhatsApp
            </a>
          ) : null}
        </article>
      ))}
      {!messages.length ? (
        <p className="card p-8 text-center text-sm text-plum-soft">No messages yet.</p>
      ) : null}
    </div>
  );
}
