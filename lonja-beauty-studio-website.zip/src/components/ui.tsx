import Link from "next/link";
import type { ReactNode } from "react";

import type { Review, Service } from "@/db/schema";
import { formatDuration, formatMoney } from "@/lib/site";

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "center",
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: "center" | "left";
}) {
  return (
    <div className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}>
      {eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}
      <h2 className="mt-2 font-display text-3xl font-bold leading-tight text-plum sm:text-4xl">
        {title}
      </h2>
      {description ? (
        <p className="mt-3 text-[0.95rem] leading-relaxed text-plum-soft/85">{description}</p>
      ) : null}
    </div>
  );
}

export function Stars({ rating, className = "" }: { rating: number; className?: string }) {
  const rounded = Math.round(rating);
  return (
    <span className={`inline-flex items-center gap-0.5 ${className}`} aria-label={`${rating} out of 5`}>
      {[1, 2, 3, 4, 5].map((value) => (
        <span key={value} className={value <= rounded ? "text-gold" : "text-plum/20"}>
          ★
        </span>
      ))}
    </span>
  );
}

export function ServiceRow({ service }: { service: Service }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-plum/8 py-3 last:border-0">
      <div>
        <p className="font-medium text-ink">
          {service.name}
          {service.isPopular ? (
            <span className="ml-2 rounded-full bg-gold/20 px-2 py-0.5 text-[0.6rem] font-bold uppercase tracking-wider text-amber-800">
              Popular
            </span>
          ) : null}
        </p>
        {service.description ? (
          <p className="mt-0.5 text-xs leading-relaxed text-plum-soft/70">{service.description}</p>
        ) : null}
        <p className="mt-1 text-[0.7rem] uppercase tracking-wider text-plum-soft/50">
          {formatDuration(service.durationMinutes)}
        </p>
      </div>
      <div className="shrink-0 text-right">
        <p className="font-display text-lg font-bold text-plum">
          {service.priceLabel ?? formatMoney(service.priceCents)}
        </p>
        <Link
          href={`/book?service=${service.id}`}
          className="text-[0.7rem] font-semibold uppercase tracking-wider text-rose-dark hover:underline"
        >
          Book
        </Link>
      </div>
    </div>
  );
}

export function ReviewCard({ review }: { review: Review }) {
  return (
    <figure className="card flex h-full flex-col p-5">
      <Stars rating={review.rating} className="text-sm" />
      <blockquote className="mt-3 flex-1 text-sm leading-relaxed text-plum-soft">
        “{review.body}”
      </blockquote>
      <figcaption className="mt-4 border-t border-plum/10 pt-3 text-xs">
        <span className="font-semibold text-ink">{review.authorName}</span>
        {review.authorMeta ? (
          <span className="block text-plum-soft/60">{review.authorMeta}</span>
        ) : null}
        {review.technicianName ? (
          <span className="mt-1 inline-block rounded-full bg-blush px-2 py-0.5 text-[0.65rem] font-semibold text-plum">
            Nails by {review.technicianName}
          </span>
        ) : null}
      </figcaption>
    </figure>
  );
}

export function Pill({ children, tone = "blush" }: { children: ReactNode; tone?: "blush" | "gold" | "plum" }) {
  const tones = {
    blush: "bg-blush text-plum",
    gold: "bg-gold/20 text-amber-900",
    plum: "bg-plum text-cream",
  };
  return (
    <span className={`rounded-full px-3 py-1 text-xs font-semibold ${tones[tone]}`}>{children}</span>
  );
}
