import { SITE, whatsappLink } from "@/lib/site";

export function FloatingActions() {
  return (
    <div className="fixed bottom-5 right-4 z-40 flex flex-col items-end gap-3">
      <a
        href={whatsappLink(
          "Hi Lonja Beauty Studio Fourways! I'd like to book an appointment please.",
        )}
        target="_blank"
        rel="noreferrer"
        aria-label="WhatsApp the studio"
        className="flex items-center gap-2 rounded-full bg-[#25D366] px-4 py-3 text-sm font-semibold text-white shadow-[0_16px_40px_-16px_rgba(37,211,102,0.8)] transition hover:brightness-105"
      >
        <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current" aria-hidden>
          <path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.95 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48 0 1.46 1.07 2.88 1.22 3.08.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.63.71.23 1.36.19 1.87.12.57-.09 1.76-.72 2.01-1.41.25-.7.25-1.29.17-1.42-.07-.13-.27-.2-.57-.35zM12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.28-1.38c1.45.79 3.08 1.2 4.75 1.2h.01c5.46 0 9.91-4.45 9.91-9.91C21.95 6.45 17.5 2 12.04 2zm5.8 15.71c-.25.7-.85 1.33-1.42 1.42" />
        </svg>
        <span className="hidden sm:inline">WhatsApp</span>
      </a>
      <a
        href={`tel:${SITE.phoneTel}`}
        aria-label="Call the studio"
        className="grid h-12 w-12 place-items-center rounded-full bg-plum text-cream shadow-soft transition hover:brightness-125 sm:hidden"
      >
        📞
      </a>
    </div>
  );
}
