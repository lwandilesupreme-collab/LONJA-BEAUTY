"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";

import type { Service, Technician } from "@/db/schema";
import {
  BOOKING_WINDOW_DAYS,
  addDaysISO,
  prettyDate,
  shortDate,
  todayISO,
} from "@/lib/booking";
import { formatDuration, formatMoney, whatsappLink } from "@/lib/site";

type Slot = { time: string; label: string; available: boolean; reason?: string; remaining: number };

const ADD_ONS = [
  { name: "Art (per nail)", priceCents: 1500 },
  { name: "3D Art (per nail)", priceCents: 2500 },
  { name: "3D Flower", priceCents: 3000 },
  { name: "Chrome (per nail)", priceCents: 2000 },
  { name: "Acrylic Soak-Off", priceCents: 8000 },
  { name: "Gel Soak-Off", priceCents: 5000 },
  { name: "Foot Scrub", priceCents: 20000 },
];

const STEPS = ["Service", "Date & time", "Your details", "Done"];

export function BookingWizard({
  services,
  technicians,
  initialServiceId,
}: {
  services: Service[];
  technicians: Technician[];
  initialServiceId?: number;
}) {
  const initial = useMemo(
    () => services.find((service) => service.id === initialServiceId) ?? null,
    [services, initialServiceId],
  );

  const [step, setStep] = useState(initial ? 1 : 0);
  const [service, setService] = useState<Service | null>(initial);
  const [category, setCategory] = useState<string>(initial?.category ?? "Nails");
  const [date, setDate] = useState<string>(addDaysISO(todayISO(), 1));
  const [time, setTime] = useState<string>("");
  const [slots, setSlots] = useState<Slot[]>([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [addOns, setAddOns] = useState<string[]>([]);
  const [technicianId, setTechnicianId] = useState<number | "">("");
  const [form, setForm] = useState({ name: "", phone: "", email: "", notes: "" });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [reference, setReference] = useState<string | null>(null);

  const categories = useMemo(
    () => Array.from(new Set(services.map((item) => item.category))),
    [services],
  );
  const visibleServices = useMemo(
    () => services.filter((item) => item.category === category),
    [services, category],
  );

  const loadSlots = useCallback(
    async (targetDate: string, serviceId: number) => {
      setLoadingSlots(true);
      setTime("");
      try {
        const response = await fetch(
          `/api/bookings?date=${targetDate}&serviceId=${serviceId}`,
          { cache: "no-store" },
        );
        const data = (await response.json()) as { ok: boolean; slots?: Slot[] };
        setSlots(data.slots ?? []);
      } catch {
        setSlots([]);
      } finally {
        setLoadingSlots(false);
      }
    },
    [],
  );

  useEffect(() => {
    if (step === 1 && service) {
      void loadSlots(date, service.id);
    }
  }, [step, date, service, loadSlots]);

  const selectedAddOns = ADD_ONS.filter((item) => addOns.includes(item.name));
  const addOnTotal = selectedAddOns.reduce((sum, item) => sum + item.priceCents, 0);
  const total = (service?.priceCents ?? 0) + addOnTotal;

  const dates = useMemo(() => {
    const today = todayISO();
    return Array.from({ length: BOOKING_WINDOW_DAYS > 21 ? 21 : BOOKING_WINDOW_DAYS }, (_, index) =>
      addDaysISO(today, index),
    );
  }, []);

  async function submit() {
    if (!service) return;
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: form.name,
          customerPhone: form.phone,
          customerEmail: form.email || null,
          serviceId: service.id,
          addOns: selectedAddOns,
          technicianId: technicianId || null,
          bookingDate: date,
          bookingTime: time,
          notes: form.notes || null,
        }),
      });
      const data = (await response.json()) as {
        ok: boolean;
        error?: string;
        booking?: { reference: string };
      };
      if (!data.ok || !data.booking) {
        setError(data.error ?? "Could not save your booking.");
        if (response.status === 409) {
          await loadSlots(date, service.id);
          setStep(1);
        }
        return;
      }
      setReference(data.booking.reference);
      setStep(3);
    } catch {
      setError("Network error — please try again or WhatsApp us.");
    } finally {
      setSubmitting(false);
    }
  }

  const technician = technicians.find((item) => item.id === technicianId) ?? null;

  return (
    <div className="grid gap-8 lg:grid-cols-[1.6fr_1fr]">
      <div>
        {/* Stepper */}
        <ol className="mb-8 flex flex-wrap items-center gap-2 text-xs font-semibold">
          {STEPS.map((label, index) => {
            const state = index === step ? "current" : index < step ? "done" : "todo";
            return (
              <li key={label} className="flex items-center gap-2">
                <span
                  className={`grid h-7 w-7 place-items-center rounded-full text-[0.7rem] ${
                    state === "current"
                      ? "bg-plum text-cream"
                      : state === "done"
                        ? "bg-emerald-500 text-white"
                        : "bg-plum/10 text-plum/50"
                  }`}
                >
                  {state === "done" ? "✓" : index + 1}
                </span>
                <span className={state === "todo" ? "text-plum/40" : "text-plum"}>{label}</span>
                {index < STEPS.length - 1 ? <span className="text-plum/25">—</span> : null}
              </li>
            );
          })}
        </ol>

        {/* STEP 1 — service */}
        {step === 0 && (
          <section className="card p-6">
            <h2 className="font-display text-2xl font-bold text-plum">What are we doing today?</h2>
            <p className="mt-1 text-sm text-plum-soft/80">
              Nail and lash services can be booked online. For braids and hair, please WhatsApp us so
              we can plan the right amount of chair time.
            </p>

            <div className="mt-5 flex flex-wrap gap-2">
              {categories.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setCategory(item)}
                  className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                    category === item ? "bg-plum text-cream" : "bg-blush text-plum hover:bg-rose-light/50"
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>

            <div className="mt-5 grid gap-2 sm:grid-cols-2">
              {visibleServices.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setService(item);
                    setStep(1);
                  }}
                  className={`rounded-xl border p-4 text-left transition ${
                    service?.id === item.id
                      ? "border-rose bg-blush"
                      : "border-plum/12 bg-white hover:border-rose/60 hover:bg-blush/40"
                  }`}
                >
                  <span className="flex items-start justify-between gap-2">
                    <span className="font-semibold text-plum">{item.name}</span>
                    <span className="shrink-0 font-display font-bold text-rose-dark">
                      {item.priceLabel ?? formatMoney(item.priceCents)}
                    </span>
                  </span>
                  <span className="mt-1 block text-xs text-plum-soft/70">
                    {formatDuration(item.durationMinutes)}
                    {item.description ? ` · ${item.description.slice(0, 46)}…` : ""}
                  </span>
                </button>
              ))}
            </div>

            <p className="mt-5 rounded-xl bg-blush/70 p-3 text-xs text-plum-soft">
              Looking for braids, relaxers or cuts?{" "}
              <Link href="/services" className="font-semibold underline">
                See the full pricelist
              </Link>{" "}
              and WhatsApp us to book.
            </p>
          </section>
        )}

        {/* STEP 2 — date & time */}
        {step === 1 && service && (
          <section className="card p-6">
            <h2 className="font-display text-2xl font-bold text-plum">Pick your date &amp; time</h2>
            <p className="mt-1 text-sm text-plum-soft/80">
              We&apos;re open 9am – 6pm, seven days a week. Same-day bookings need an hour&apos;s
              notice.
            </p>

            <div className="mt-5 -mx-1 flex gap-2 overflow-x-auto px-1 pb-2">
              {dates.map((iso) => (
                <button
                  key={iso}
                  type="button"
                  onClick={() => setDate(iso)}
                  className={`shrink-0 rounded-xl border px-4 py-3 text-center transition ${
                    date === iso
                      ? "border-plum bg-plum text-cream"
                      : "border-plum/12 bg-white text-plum hover:border-rose"
                  }`}
                >
                  <span className="block text-[0.65rem] uppercase tracking-wider opacity-70">
                    {shortDate(iso).split(",")[0]}
                  </span>
                  <span className="block text-sm font-semibold">{shortDate(iso).split(", ")[1]}</span>
                </button>
              ))}
            </div>

            <p className="mt-4 text-sm font-semibold text-plum">{prettyDate(date)}</p>

            {loadingSlots ? (
              <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4">
                {Array.from({ length: 12 }).map((_, index) => (
                  <div key={index} className="h-11 animate-pulse rounded-xl bg-plum/10" />
                ))}
              </div>
            ) : (
              <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4">
                {slots.map((slot) => (
                  <button
                    key={slot.time}
                    type="button"
                    disabled={!slot.available}
                    onClick={() => setTime(slot.time)}
                    title={slot.reason ?? ""}
                    className={`rounded-xl border px-2 py-2.5 text-sm font-semibold transition ${
                      time === slot.time
                        ? "border-plum bg-plum text-cream"
                        : slot.available
                          ? "border-plum/12 bg-white text-plum hover:border-rose hover:bg-blush/50"
                          : "cursor-not-allowed border-plum/8 bg-plum/5 text-plum/30 line-through"
                    }`}
                  >
                    {slot.label}
                  </button>
                ))}
                {!slots.length ? (
                  <p className="col-span-3 text-sm text-plum-soft sm:col-span-4">
                    No slots available for this date. Please try another day or call us.
                  </p>
                ) : null}
              </div>
            )}

            <div className="mt-6 flex justify-between gap-3">
              <button type="button" onClick={() => setStep(0)} className="btn btn-ghost">
                ← Change service
              </button>
              <button
                type="button"
                disabled={!time}
                onClick={() => setStep(2)}
                className={`btn btn-primary ${time ? "" : "cursor-not-allowed opacity-40"}`}
              >
                Continue →
              </button>
            </div>
          </section>
        )}

        {/* STEP 3 — details */}
        {step === 2 && service && (
          <section className="card p-6">
            <h2 className="font-display text-2xl font-bold text-plum">Almost done</h2>
            <p className="mt-1 text-sm text-plum-soft/80">
              We only need a name and number to hold your chair.
            </p>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="label" htmlFor="name">
                  Full name *
                </label>
                <input
                  id="name"
                  className="field"
                  value={form.name}
                  onChange={(event) => setForm({ ...form, name: event.target.value })}
                  placeholder="e.g. Lerato Mashigo"
                />
              </div>
              <div>
                <label className="label" htmlFor="phone">
                  Mobile number *
                </label>
                <input
                  id="phone"
                  className="field"
                  inputMode="tel"
                  value={form.phone}
                  onChange={(event) => setForm({ ...form, phone: event.target.value })}
                  placeholder="073 086 6933"
                />
              </div>
              <div>
                <label className="label" htmlFor="email">
                  Email (optional)
                </label>
                <input
                  id="email"
                  type="email"
                  className="field"
                  value={form.email}
                  onChange={(event) => setForm({ ...form, email: event.target.value })}
                  placeholder="you@example.com"
                />
              </div>

              <div className="sm:col-span-2">
                <span className="label">Add-ons (optional)</span>
                <div className="flex flex-wrap gap-2">
                  {ADD_ONS.map((item) => {
                    const active = addOns.includes(item.name);
                    return (
                      <button
                        key={item.name}
                        type="button"
                        onClick={() =>
                          setAddOns((current) =>
                            active
                              ? current.filter((name) => name !== item.name)
                              : [...current, item.name],
                          )
                        }
                        className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition ${
                          active
                            ? "border-rose bg-rose text-white"
                            : "border-plum/15 bg-white text-plum hover:border-rose"
                        }`}
                      >
                        {item.name} · {formatMoney(item.priceCents)}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="label" htmlFor="tech">
                  Preferred nail tech
                </label>
                <select
                  id="tech"
                  className="field"
                  value={technicianId}
                  onChange={(event) =>
                    setTechnicianId(event.target.value ? Number(event.target.value) : "")
                  }
                >
                  <option value="">No preference — first available</option>
                  {technicians.map((tech) => (
                    <option key={tech.id} value={tech.id}>
                      {tech.name} — {tech.role}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="label" htmlFor="notes">
                  Anything we should know?
                </label>
                <textarea
                  id="notes"
                  rows={3}
                  className="field"
                  value={form.notes}
                  onChange={(event) => setForm({ ...form, notes: event.target.value })}
                  placeholder="Inspo pics, existing set that needs a soak-off, running late…"
                />
              </div>
            </div>

            {error ? (
              <p className="mt-4 rounded-xl bg-rose-50 p-3 text-sm text-rose-700 ring-1 ring-rose-200">
                {error}
              </p>
            ) : null}

            <div className="mt-6 flex flex-wrap justify-between gap-3">
              <button type="button" onClick={() => setStep(1)} className="btn btn-ghost">
                ← Back
              </button>
              <button
                type="button"
                disabled={submitting || form.name.trim().length < 2 || form.phone.trim().length < 9}
                onClick={submit}
                className={`btn btn-primary ${
                  submitting || form.name.trim().length < 2 || form.phone.trim().length < 9
                    ? "cursor-not-allowed opacity-50"
                    : ""
                }`}
              >
                {submitting ? "Saving…" : `Confirm booking · ${formatMoney(total)}`}
              </button>
            </div>
          </section>
        )}

        {/* STEP 4 — done */}
        {step === 3 && service && (
          <section className="card p-8 text-center">
            <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-emerald-100 text-3xl">
              ✅
            </span>
            <h2 className="mt-4 font-display text-3xl font-bold text-plum">Booking requested!</h2>
            <p className="mt-2 text-sm text-plum-soft">
              Your reference is{" "}
              <strong className="font-display text-lg text-plum">{reference}</strong> — keep it handy
              or screenshot this page.
            </p>
            <div className="mx-auto mt-6 max-w-md rounded-2xl bg-blush/70 p-5 text-left text-sm">
              <p className="font-semibold text-plum">Booking summary</p>
              <ul className="mt-3 space-y-1.5 text-plum-soft">
                <li>
                  <strong className="text-ink">Service:</strong> {service.name}
                </li>
                {selectedAddOns.length ? (
                  <li>
                    <strong className="text-ink">Add-ons:</strong>{" "}
                    {selectedAddOns.map((item) => item.name).join(", ")}
                  </li>
                ) : null}
                <li>
                  <strong className="text-ink">When:</strong> {prettyDate(date)} at{" "}
                  {slots.find((slot) => slot.time === time)?.label ?? time}
                </li>
                <li>
                  <strong className="text-ink">With:</strong> {technician?.name ?? "First available"}
                </li>
                <li>
                  <strong className="text-ink">Total:</strong> {formatMoney(total)} (pay in studio)
                </li>
              </ul>
            </div>
            <div className="mt-7 flex flex-wrap justify-center gap-3">
              <a
                href={whatsappLink(
                  `Hi Lonja Beauty Studio Fourways! I just booked online. Reference ${reference} — ${service.name} on ${prettyDate(date)}.`,
                )}
                target="_blank"
                rel="noreferrer"
                className="btn btn-primary"
              >
                💬 Send us your booking
              </a>
              <Link href="/track" className="btn btn-ghost">
                Manage my booking
              </Link>
            </div>
            <p className="mt-5 text-xs text-plum-soft/70">
              We&apos;ll confirm by WhatsApp during business hours (9am–6pm). Need to change
              something? Please give us at least 4 hours&apos; notice.
            </p>
          </section>
        )}
      </div>

      {/* Summary rail */}
      <aside className="lg:sticky lg:top-28 lg:self-start">
        <div className="card p-6">
          <p className="eyebrow">Your booking</p>
          <h3 className="mt-2 font-display text-2xl font-bold text-plum">Summary</h3>

          <dl className="mt-5 space-y-3 text-sm">
            <div className="flex justify-between gap-3 border-b border-plum/8 pb-2">
              <dt className="text-plum-soft">Service</dt>
              <dd className="text-right font-medium text-ink">
                {service ? (
                  <>
                    {service.name}
                    <span className="block text-xs text-plum-soft/70">
                      {formatDuration(service.durationMinutes)}
                    </span>
                  </>
                ) : (
                  <span className="text-plum/40">Not selected</span>
                )}
              </dd>
            </div>
            <div className="flex justify-between gap-3 border-b border-plum/8 pb-2">
              <dt className="text-plum-soft">When</dt>
              <dd className="text-right font-medium text-ink">
                {time ? (
                  <>
                    {shortDate(date)}
                    <span className="block text-xs text-plum-soft/70">
                      {slots.find((slot) => slot.time === time)?.label ?? time}
                    </span>
                  </>
                ) : (
                  <span className="text-plum/40">Not selected</span>
                )}
              </dd>
            </div>
            <div className="flex justify-between gap-3 border-b border-plum/8 pb-2">
              <dt className="text-plum-soft">Tech</dt>
              <dd className="text-right font-medium text-ink">
                {technician?.name ?? "First available"}
              </dd>
            </div>
            {selectedAddOns.map((item) => (
              <div key={item.name} className="flex justify-between gap-3 text-sm">
                <dt className="text-plum-soft">+ {item.name}</dt>
                <dd className="text-ink">{formatMoney(item.priceCents)}</dd>
              </div>
            ))}
          </dl>

          <div className="mt-5 flex items-baseline justify-between rounded-xl bg-plum px-4 py-3 text-cream">
            <span className="text-sm">Estimated total</span>
            <span className="font-display text-2xl font-bold">{formatMoney(total)}</span>
          </div>
          <p className="mt-2 text-xs text-plum-soft/70">
            No deposit required — pay in studio by card or cash.
          </p>
        </div>

        <div className="card mt-4 p-6">
          <p className="eyebrow">Studio</p>
          <p className="mt-2 text-sm font-semibold text-plum">264 Pritchard St, Fourways</p>
          <p className="text-sm text-plum-soft">Johannesburg, 2196</p>
          <ul className="mt-4 space-y-1.5 text-sm text-plum-soft">
            <li>🕘 Open 7 days · 9am – 6pm</li>
            <li>🚗 Free street parking nearby</li>
            <li>☕ Coffee &amp; juice on the house</li>
          </ul>
        </div>
      </aside>
    </div>
  );
}


