import Link from "next/link";

import { SITE, whatsappLink } from "@/lib/site";

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-plum text-cream">
      <div className="container-x grid gap-10 py-14 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-full bg-cream text-plum font-display text-xl font-bold">
              L
            </span>
            <div>
              <p className="font-display text-2xl font-bold">Lonja Beauty</p>
              <p className="text-[0.62rem] uppercase tracking-[0.3em] text-rose-light">
                Fourways Studio
              </p>
            </div>
          </div>
          <p className="mt-4 text-sm leading-relaxed text-cream/80">
            Nails, lashes and hair in the heart of Fourways. Walk in for a buff &amp; shine, or book
            ahead for a full set with one of our senior nail techs.
          </p>
          <p className="mt-4 flex items-center gap-2 text-sm">
            <span className="text-gold">★★★★☆</span>
            <span className="text-cream/80">
              {SITE.rating} · {SITE.reviewCount} Google reviews
            </span>
          </p>
        </div>

        <div>
          <h3 className="font-display text-lg font-semibold">Visit</h3>
          <ul className="mt-4 space-y-2 text-sm text-cream/80">
            <li>{SITE.address.street}</li>
            <li>
              {SITE.address.area}, {SITE.address.city}
            </li>
            <li>{SITE.address.code}</li>
            <li className="pt-2">
              <a
                href={SITE.mapsDirections}
                target="_blank"
                rel="noreferrer"
                className="underline decoration-rose-light/60 underline-offset-4 hover:text-white"
              >
                Get directions →
              </a>
            </li>
            <li className="text-cream/60">Plus code: {SITE.plusCode}</li>
          </ul>
        </div>

        <div>
          <h3 className="font-display text-lg font-semibold">Hours</h3>
          <ul className="mt-4 space-y-1.5 text-sm text-cream/80">
            <li className="flex justify-between gap-4">
              <span>Monday – Sunday</span>
              <span className="text-cream">9:00 am – 6:00 pm</span>
            </li>
            <li className="pt-2 text-cream/60">Open all 7 days · Public holidays may vary</li>
          </ul>
          <h3 className="mt-6 font-display text-lg font-semibold">Contact</h3>
          <ul className="mt-3 space-y-2 text-sm text-cream/80">
            <li>
              <a href={`tel:${SITE.phoneTel}`} className="hover:text-white">
                {SITE.phoneDisplay}
              </a>
            </li>
            <li>
              <a
                href={whatsappLink("Hi Lonja Beauty Studio Fourways!")}
                target="_blank"
                rel="noreferrer"
                className="hover:text-white"
              >
                WhatsApp the studio
              </a>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="font-display text-lg font-semibold">Explore</h3>
          <ul className="mt-4 space-y-2 text-sm text-cream/80">
            {[
              { href: "/services", label: "Full pricelist" },
              { href: "/book", label: "Book an appointment" },
              { href: "/gallery", label: "Nail gallery" },
              { href: "/team", label: "Meet the techs" },
              { href: "/reviews", label: "Reviews" },
              { href: "/track", label: "Find my booking" },
              { href: "/admin", label: "Studio admin" },
            ].map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="hover:text-white">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-cream/15">
        <div className="container-x flex flex-col items-center justify-between gap-2 py-5 text-xs text-cream/60 sm:flex-row">
          <p>
            © {new Date().getFullYear()} {SITE.fullName}. All rights reserved.
          </p>
          <p>Made with 💅 in Fourways, Johannesburg</p>
        </div>
      </div>
    </footer>
  );
}
