"use client";

import { useState } from "react";

import { SITE, whatsappLink } from "@/lib/site";

export function ContactForm() {
  const [form, setForm] = useState({ name: "", phone: "", email: "", subject: "", body: "" });
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setState("sending");
    setError(null);
    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = (await response.json()) as { ok: boolean; error?: string };
      if (!data.ok) {
        setError(data.error ?? "Could not send your message.");
        setState("error");
        return;
      }
      setState("done");
      setForm({ name: "", phone: "", email: "", subject: "", body: "" });
    } catch {
      setError("Network error — please try again.");
      setState("error");
    }
  }

  if (state === "done") {
    return (
      <div className="card p-8 text-center">
        <span className="text-4xl">💌</span>
        <h3 className="mt-3 font-display text-2xl font-bold text-plum">Message sent</h3>
        <p className="mx-auto mt-2 max-w-md text-sm text-plum-soft">
          Thanks! The studio reads messages during business hours. For anything urgent, WhatsApp us
          on {SITE.phoneDisplay}.
        </p>
        <button type="button" onClick={() => setState("idle")} className="btn btn-ghost mt-5">
          Send another
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="card p-6 sm:p-8">
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="c-name">
            Name *
          </label>
          <input
            id="c-name"
            className="field"
            value={form.name}
            onChange={(event) => setForm({ ...form, name: event.target.value })}
          />
        </div>
        <div>
          <label className="label" htmlFor="c-phone">
            Mobile
          </label>
          <input
            id="c-phone"
            className="field"
            inputMode="tel"
            value={form.phone}
            onChange={(event) => setForm({ ...form, phone: event.target.value })}
          />
        </div>
        <div>
          <label className="label" htmlFor="c-email">
            Email
          </label>
          <input
            id="c-email"
            type="email"
            className="field"
            value={form.email}
            onChange={(event) => setForm({ ...form, email: event.target.value })}
          />
        </div>
        <div>
          <label className="label" htmlFor="c-subject">
            Subject
          </label>
          <select
            id="c-subject"
            className="field"
            value={form.subject}
            onChange={(event) => setForm({ ...form, subject: event.target.value })}
          >
            <option value="">General enquiry</option>
            <option value="Booking help">Booking help</option>
            <option value="Group / event booking">Group or ladies night booking</option>
            <option value="Careers">Careers — I&apos;d like to join the team</option>
            <option value="Feedback">Feedback</option>
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="label" htmlFor="c-body">
            Message *
          </label>
          <textarea
            id="c-body"
            rows={5}
            className="field"
            value={form.body}
            onChange={(event) => setForm({ ...form, body: event.target.value })}
            placeholder="How can we help?"
          />
        </div>
      </div>

      {error ? (
        <p className="mt-4 rounded-xl bg-rose-50 p-3 text-sm text-rose-700 ring-1 ring-rose-200">
          {error}
        </p>
      ) : null}

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button
          type="submit"
          disabled={state === "sending" || form.name.trim().length < 2 || form.body.trim().length < 5}
          className={`btn btn-primary ${
            state === "sending" || form.name.trim().length < 2 || form.body.trim().length < 5
              ? "cursor-not-allowed opacity-50"
              : ""
          }`}
        >
          {state === "sending" ? "Sending…" : "Send message"}
        </button>
        <a
          href={whatsappLink("Hi Lonja Beauty Studio Fourways!")}
          target="_blank"
          rel="noreferrer"
          className="btn btn-ghost"
        >
          💬 WhatsApp instead
        </a>
      </div>
    </form>
  );
}
