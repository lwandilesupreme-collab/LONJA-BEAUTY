"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

import { SITE, whatsappLink } from "@/lib/site";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/services", label: "Pricelist" },
  { href: "/book", label: "Book Now" },
  { href: "/gallery", label: "Gallery" },
  { href: "/team", label: "Our Techs" },
  { href: "/reviews", label: "Reviews" },
  { href: "/contact", label: "Find Us" },
];

export function SiteHeader() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  if (pathname?.startsWith("/admin")) return null;

  return (
    <>
      <div className="bg-plum text-cream text-[0.72rem] sm:text-xs">
        <div className="container-x flex items-center justify-center gap-2 py-2 text-center">
          <span className="hidden sm:inline">💅</span>
          <span>
            Ladies Night every Thursday 4–8pm · bring a friend &amp; you both get 10% off nails
          </span>
        </div>
      </div>

      <header
        className={`sticky top-0 z-50 transition-all ${
          scrolled
            ? "bg-cream/95 backdrop-blur border-b border-plum/10 shadow-[0_10px_30px_-24px_rgba(74,31,44,0.6)]"
            : "bg-cream/80 backdrop-blur border-b border-transparent"
        }`}
      >
        <div className="container-x flex items-center justify-between gap-4 py-3">
          <Link href="/" className="flex items-center gap-3 shrink-0">
            <span className="grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br from-plum to-rose-dark text-cream font-display text-lg font-bold shadow-soft">
              L
            </span>
            <span className="leading-tight">
              <span className="block font-display text-xl font-bold text-plum">
                Lonja <span className="text-rose-dark">Beauty</span>
              </span>
              <span className="block text-[0.6rem] uppercase tracking-[0.28em] text-rose-dark">
                Fourways Studio
              </span>
            </span>
          </Link>

          <nav className="hidden lg:flex items-center gap-1">
            {NAV.map((item) => {
              const active =
                item.href === "/" ? pathname === "/" : pathname?.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`rounded-full px-3.5 py-2 text-sm font-medium transition-colors ${
                    active
                      ? "bg-blush text-plum"
                      : "text-plum-soft hover:bg-blush/70 hover:text-plum"
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-2">
            <a
              href={`tel:${SITE.phoneTel}`}
              className="hidden sm:inline-flex btn btn-ghost !py-2 !px-4 text-sm"
            >
              📞 {SITE.phoneDisplay}
            </a>
            <Link href="/book" className="btn btn-primary !py-2.5 !px-5 text-sm">
              Book
            </Link>
            <button
              type="button"
              aria-label="Toggle menu"
              onClick={() => setOpen((value) => !value)}
              className="lg:hidden grid h-10 w-10 place-items-center rounded-full border border-plum/20 text-plum"
            >
              <span className="text-lg">{open ? "✕" : "☰"}</span>
            </button>
          </div>
        </div>

        {open && (
          <div className="lg:hidden border-t border-plum/10 bg-cream">
            <nav className="container-x grid gap-1 py-3">
              {NAV.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="rounded-xl px-3 py-2.5 text-sm font-medium text-plum hover:bg-blush"
                >
                  {item.label}
                </Link>
              ))}
              <a
                href={whatsappLink("Hi Lonja Beauty Studio Fourways! I'd like to make a booking.")}
                target="_blank"
                rel="noreferrer"
                className="rounded-xl px-3 py-2.5 text-sm font-medium text-emerald-700 hover:bg-emerald-50"
              >
                💬 WhatsApp us
              </a>
            </nav>
          </div>
        )}
      </header>
    </>
  );
}
