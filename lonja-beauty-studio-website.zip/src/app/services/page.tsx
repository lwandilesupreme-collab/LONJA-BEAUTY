import Link from "next/link";
import type { Metadata } from "next";

import { ServiceRow, SectionHeading } from "@/components/ui";
import { getServices } from "@/lib/data";
import { CATEGORY_META, CATEGORY_ORDER } from "@/lib/pricelist";
import { formatMoney } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Pricelist — Nails, Lashes, Hair & Cuts",
  description:
    "Full Lonja Beauty Studio Fourways pricelist. Acrylic tips from R190, gel hands R150, polygel R380, cat eye R480, lashes from R230, braids and haircuts.",
};

export default async function ServicesPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; q?: string }>;
}) {
  const params = await searchParams;
  const all = await getServices();

  const q = (params.q ?? "").trim().toLowerCase();
  const category = params.category ?? "Nails";
  const activeCategory = CATEGORY_ORDER.includes(category as (typeof CATEGORY_ORDER)[number])
    ? category
    : null;

  const filtered = all.filter((service) => {
    const matchesCategory = activeCategory ? service.category === activeCategory : true;
    const haystack = `${service.name} ${service.subcategory ?? ""} ${service.description ?? ""}`.toLowerCase();
    const matchesQuery = q ? haystack.includes(q) : true;
    return matchesCategory && matchesQuery;
  });

  const grouped = filtered.reduce<Record<string, typeof filtered>>((acc, service) => {
    const key = service.subcategory ?? "All services";
    acc[key] = acc[key] ?? [];
    acc[key].push(service);
    return acc;
  }, {});

  const counts = CATEGORY_ORDER.map((name) => ({
    name,
    count: all.filter((service) => service.category === name).length,
  }));

  return (
    <div className="bg-cream">
      <section className="border-b border-plum/10 bg-gradient-to-b from-blush to-cream py-12">
        <div className="container-x">
          <SectionHeading
            eyebrow="The full menu"
            title="Lonja Beauty Studio pricelist"
            description="Every price below is the real studio price in South African Rand. Bookable services open straight into our online calendar."
          />
          <form action="/services" className="mx-auto mt-8 flex max-w-xl gap-2">
            <input
              type="search"
              name="q"
              defaultValue={params.q ?? ""}
              placeholder="Search “cat eye”, “knotless”, “fade”…"
              className="field"
              aria-label="Search services"
            />
            {activeCategory ? (
              <input type="hidden" name="category" value={activeCategory} />
            ) : null}
            <button type="submit" className="btn btn-primary shrink-0">
              Search
            </button>
          </form>
        </div>
      </section>

      <div className="container-x py-10">
        <div className="flex flex-wrap items-center gap-2">
          <Link
            href={`/services${params.q ? `?q=${encodeURIComponent(params.q)}` : ""}`}
            className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
              activeCategory === null ? "bg-plum text-cream" : "bg-blush text-plum hover:bg-rose-light/50"
            }`}
          >
            Everything ({all.length})
          </Link>
          {counts.map((item) => (
            <Link
              key={item.name}
              href={`/services?category=${encodeURIComponent(item.name)}${
                params.q ? `&q=${encodeURIComponent(params.q)}` : ""
              }`}
              className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                activeCategory === item.name
                  ? "bg-plum text-cream"
                  : "bg-blush text-plum hover:bg-rose-light/50"
              }`}
            >
              {CATEGORY_META[item.name].icon} {item.name} ({item.count})
            </Link>
          ))}
        </div>

        {q ? (
          <p className="mt-5 text-sm text-plum-soft">
            {filtered.length} result{filtered.length === 1 ? "" : "s"} for “{params.q}”.{" "}
            <Link href="/services" className="underline">
              Clear search
            </Link>
          </p>
        ) : null}

        {filtered.length === 0 ? (
          <div className="card mt-8 p-10 text-center">
            <p className="font-display text-2xl text-plum">Nothing matched that search</p>
            <p className="mt-2 text-sm text-plum-soft">
              Try “acrylic”, “gel”, “braid”, “lash” or give us a call on 073 086 6933.
            </p>
          </div>
        ) : (
          <div className="mt-8 grid gap-6 lg:grid-cols-2">
            {Object.entries(grouped).map(([group, items]) => (
              <div key={group} className="card p-6">
                <div className="flex items-baseline justify-between gap-3 border-b border-plum/10 pb-3">
                  <h2 className="font-display text-2xl font-bold text-plum">{group}</h2>
                  <span className="text-xs uppercase tracking-widest text-rose-dark">
                    {CATEGORY_META[items[0].category]?.icon} {items[0].category}
                  </span>
                </div>
                <div className="mt-2">
                  {items.map((service) => (
                    <ServiceRow key={service.id} service={service} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="card mt-10 grid gap-6 p-6 sm:grid-cols-3 sm:p-8">
          <div>
            <p className="eyebrow">Good to know</p>
            <h3 className="mt-2 font-display text-xl font-bold text-plum">What&apos;s included</h3>
            <p className="mt-2 text-sm leading-relaxed text-plum-soft/85">
              Shape, cuticle care and a top coat are included in every nail service. Soak-off of an
              existing set is charged separately.
            </p>
          </div>
          <div>
            <p className="eyebrow">Add-ons</p>
            <h3 className="mt-2 font-display text-xl font-bold text-plum">Make it yours</h3>
            <ul className="mt-2 space-y-1 text-sm text-plum-soft/85">
              <li>Art per nail — {formatMoney(1500)}</li>
              <li>3D art per nail — {formatMoney(2500)}</li>
              <li>3D flower — {formatMoney(3000)}</li>
              <li>Chrome per nail — {formatMoney(2000)}</li>
            </ul>
          </div>
          <div>
            <p className="eyebrow">Ready?</p>
            <h3 className="mt-2 font-display text-xl font-bold text-plum">Book your slot</h3>
            <p className="mt-2 text-sm text-plum-soft/85">
              Online booking is free and takes under a minute. We confirm by WhatsApp.
            </p>
            <Link href="/book" className="btn btn-primary mt-4">
              Book now
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
