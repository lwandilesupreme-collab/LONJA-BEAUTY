import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";

import { SectionHeading } from "@/components/ui";
import { getGallery } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Nail Gallery",
  description:
    "Browse recent acrylic, gel, polygel, cat eye, ombre and 3D nail art sets done at Lonja Beauty Studio Fourways.",
};

export default async function GalleryPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const params = await searchParams;
  const items = await getGallery();
  const categories = Array.from(new Set(items.map((item) => item.category)));
  const active = params.category && categories.includes(params.category) ? params.category : null;
  const visible = active ? items.filter((item) => item.category === active) : items;

  return (
    <div className="bg-cream py-12">
      <div className="container-x">
        <SectionHeading
          eyebrow="Portfolio"
          title="The Lonja nail gallery"
          description="Bring us a photo, or pick one of these. Every set is shaped and finished to suit your nail bed and lifestyle."
        />

        <div className="mt-8 flex flex-wrap justify-center gap-2">
          <Link
            href="/gallery"
            className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
              active === null ? "bg-plum text-cream" : "bg-blush text-plum hover:bg-rose-light/50"
            }`}
          >
            All work
          </Link>
          {categories.map((category) => (
            <Link
              key={category}
              href={`/gallery?category=${encodeURIComponent(category)}`}
              className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                active === category
                  ? "bg-plum text-cream"
                  : "bg-blush text-plum hover:bg-rose-light/50"
              }`}
            >
              {category}
            </Link>
          ))}
        </div>

        <div className="mt-10 columns-2 gap-4 sm:columns-3 lg:columns-4 [&>*]:mb-4">
          {visible.map((item) => (
            <figure key={item.id} className="group relative overflow-hidden rounded-2xl shadow-soft">
              <Image
                src={item.imageUrl}
                alt={item.title}
                width={800}
                height={1000}
                className="w-full object-cover transition duration-500 group-hover:scale-[1.04]"
              />
              <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-plum/90 to-transparent p-4 pt-12">
                <p className="font-semibold text-cream">{item.title}</p>
                <p className="text-xs text-cream/75">
                  {item.technicianName ? `by ${item.technicianName} · ` : ""}
                  {item.category}
                </p>
              </figcaption>
            </figure>
          ))}
        </div>

        <div className="card mt-12 p-8 text-center">
          <h2 className="font-display text-2xl font-bold text-plum">Want a set like these?</h2>
          <p className="mx-auto mt-2 max-w-lg text-sm text-plum-soft">
            Acrylic tips start at R190 and full art sets from R350. Book online in under a minute —
            we&apos;ll confirm on WhatsApp.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link href="/book" className="btn btn-primary">
              Book my set
            </Link>
            <Link href="/services" className="btn btn-ghost">
              See prices
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
