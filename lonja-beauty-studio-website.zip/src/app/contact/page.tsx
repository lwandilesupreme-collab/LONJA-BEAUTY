import type { Metadata } from "next";
import Link from "next/link";

import { ContactForm } from "@/components/contact-form";
import { SectionHeading } from "@/components/ui";
import { SITE, whatsappLink } from "@/lib/site";

export const metadata: Metadata = {
  title: "Find Us & Contact",
  description:
    "Lonja Beauty Studio Fourways — 264 Pritchard St, Fourways, Johannesburg, 2196. Open 7 days, 9am to 6pm. Call or WhatsApp 073 086 6933.",
};

const FAQS = [
  {
    q: "Do I need to pay a deposit?",
    a: "No. Online bookings are free to make and you pay in studio by card or cash after your service.",
  },
  {
    q: "Do you take walk-ins?",
    a: "Yes, subject to availability. Booked clients are seen first, so we recommend booking online or WhatsApping us to check the day's availability.",
  },
  {
    q: "How long does a full set take?",
    a: "Acrylic tips take about 90 minutes, a French or ombre set around 2 hours, and cat eye or polygel sets up to 2 hours 15 minutes.",
  },
  {
    q: "Is soak-off included in the price?",
    a: "No — soak-offs are charged separately at R80 for acrylic and R50 for gel. Please mention it when booking so we allow the extra time.",
  },
  {
    q: "Do you do group or ladies night bookings?",
    a: "Absolutely. Thursday is Ladies Night from 4pm to 8pm. WhatsApp us with your group size and we'll block chairs together.",
  },
  {
    q: "My nails lifted / broke — what now?",
    a: "Bring it back within 7 days of your appointment and we'll repair it free of charge.",
  },
];

export default function ContactPage() {
  return (
    <div className="bg-cream py-12">
      <div className="container-x">
        <SectionHeading
          eyebrow="Find us"
          title="264 Pritchard Street, Fourways"
          description="We're inside Fourways, a short drive from the mall, with street parking nearby. Open every day from 9am to 6pm."
        />

        <div className="mt-10 grid gap-6 lg:grid-cols-[1fr_1.2fr]">
          <div className="space-y-4">
            <div className="card p-6">
              <p className="eyebrow">Studio details</p>
              <ul className="mt-4 space-y-4 text-sm">
                <li className="flex gap-3">
                  <span>📍</span>
                  <span>
                    <strong className="block text-ink">{SITE.address.street}</strong>
                    <span className="text-plum-soft">
                      {SITE.address.area}, {SITE.address.city} {SITE.address.code}
                    </span>
                    <span className="mt-1 block text-xs text-plum-soft/60">
                      Plus code: {SITE.plusCode}
                    </span>
                  </span>
                </li>
                <li className="flex gap-3">
                  <span>📞</span>
                  <a href={`tel:${SITE.phoneTel}`} className="font-semibold text-plum hover:underline">
                    {SITE.phoneDisplay}
                  </a>
                </li>
                <li className="flex gap-3">
                  <span>💬</span>
                  <a
                    href={whatsappLink("Hi Lonja Beauty Studio Fourways!")}
                    target="_blank"
                    rel="noreferrer"
                    className="font-semibold text-emerald-700 hover:underline"
                  >
                    WhatsApp the studio
                  </a>
                </li>
                <li className="flex gap-3">
                  <span>🕘</span>
                  <span className="text-plum-soft">
                    Monday – Sunday
                    <strong className="block text-ink">9:00 am – 6:00 pm</strong>
                  </span>
                </li>
              </ul>
              <div className="mt-6 flex flex-wrap gap-3">
                <a
                  href={SITE.mapsDirections}
                  target="_blank"
                  rel="noreferrer"
                  className="btn btn-primary !py-2.5 text-sm"
                >
                  Get directions
                </a>
                <Link href="/book" className="btn btn-ghost !py-2.5 text-sm">
                  Book online
                </Link>
              </div>
            </div>

            <div className="card overflow-hidden">
              <iframe
                title="Map to Lonja Beauty Studio Fourways"
                src={SITE.mapsEmbed}
                className="h-72 w-full border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>

            <div className="card p-6">
              <p className="eyebrow">Social</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {SITE.socials.map((social) => (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-full bg-blush px-4 py-2 text-xs font-semibold text-plum hover:bg-rose-light/50"
                  >
                    {social.label} · {social.handle}
                  </a>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <ContactForm />

            <div className="card p-6 sm:p-8">
              <p className="eyebrow">FAQs</p>
              <h2 className="mt-2 font-display text-2xl font-bold text-plum">Quick answers</h2>
              <div className="mt-4 divide-y divide-plum/10">
                {FAQS.map((faq) => (
                  <details key={faq.q} className="group py-3">
                    <summary className="cursor-pointer list-none text-sm font-semibold text-plum marker:hidden">
                      <span className="flex items-start justify-between gap-3">
                        {faq.q}
                        <span className="mt-0.5 text-rose-dark transition group-open:rotate-45">
                          ＋
                        </span>
                      </span>
                    </summary>
                    <p className="mt-2 text-sm leading-relaxed text-plum-soft/85">{faq.a}</p>
                  </details>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
