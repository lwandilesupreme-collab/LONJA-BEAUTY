import type { Metadata } from "next";

import { BookingWizard } from "@/components/booking-wizard";
import { getBookableServices, getTechnicians } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Book an Appointment",
  description:
    "Book your nails, lashes or beauty appointment at Lonja Beauty Studio Fourways online. Choose your service, tech and time — no deposit needed.",
};

export default async function BookPage({
  searchParams,
}: {
  searchParams: Promise<{ service?: string }>;
}) {
  const params = await searchParams;
  const [services, technicians] = await Promise.all([getBookableServices(), getTechnicians()]);
  const serviceId = Number(params.service ?? 0);

  return (
    <div className="bg-gradient-to-b from-blush/70 to-cream py-12">
      <div className="container-x">
        <div className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">Online booking</p>
          <h1 className="mt-2 font-display text-4xl font-bold text-plum sm:text-5xl">
            Book your chair at Lonja
          </h1>
          <p className="mt-3 text-[0.95rem] text-plum-soft">
            Four simple steps. Pick a service, choose a time, and we&apos;ll confirm on WhatsApp. No
            deposit needed.
          </p>
        </div>

        <div className="mt-12">
          <BookingWizard
            services={services}
            technicians={technicians}
            initialServiceId={Number.isFinite(serviceId) && serviceId > 0 ? serviceId : undefined}
          />
        </div>
      </div>
    </div>
  );
}
