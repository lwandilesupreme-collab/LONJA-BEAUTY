import type { Metadata } from "next";
import Link from "next/link";

import { AdminBookings } from "@/components/admin/admin-bookings";
import { AdminLogin } from "@/components/admin/admin-login";
import { AdminMessages, AdminReviews } from "@/components/admin/admin-reviews";
import { LogoutButton } from "@/components/admin/logout-button";
import { isAdmin } from "@/lib/auth";
import { prettyDate, prettyTime, todayISO } from "@/lib/booking";
import {
  getAllBookings,
  getAllReviews,
  getBookingsByDate,
  getDashboardStats,
  getMessages,
} from "@/lib/data";
import { formatMoney } from "@/lib/site";
import {
  getSupabaseProjectUrl,
  isSupabaseConfigured,
  maskDatabaseUrl,
} from "@/lib/supabase";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Studio Admin",
  robots: { index: false, follow: false },
};

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "today", label: "Today" },
  { key: "bookings", label: "All bookings" },
  { key: "reviews", label: "Reviews" },
  { key: "messages", label: "Messages" },
];

export default async function AdminPage({
  searchParams,
}: {
  searchParams: Promise<{ tab?: string; status?: string }>;
}) {
  if (!(await isAdmin())) {
    return <AdminLogin />;
  }

  const params = await searchParams;
  const tab = TABS.some((item) => item.key === params.tab) ? params.tab! : "overview";

  const [stats, today, allBookings, allReviews, messages] = await Promise.all([
    getDashboardStats(),
    getBookingsByDate(todayISO()),
    getAllBookings(params.status),
    getAllReviews(),
    getMessages(),
  ]);

  const pendingReviews = allReviews.filter((review) => !review.isApproved).length;

  return (
    <div className="min-h-screen bg-[#f7f4f2]">
      <header className="bg-plum text-cream">
        <div className="container-x flex flex-wrap items-center justify-between gap-4 py-5">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-full bg-cream font-display text-lg font-bold text-plum">
              L
            </span>
            <div>
              <p className="font-display text-2xl font-bold">Lonja Studio Admin</p>
              <p className="text-[0.65rem] uppercase tracking-[0.25em] text-rose-light">
                Fourways · {prettyDate(todayISO())}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/" className="btn border border-cream/30 !py-2 !px-4 text-xs text-cream">
              View site
            </Link>
            <LogoutButton />
          </div>
        </div>
      </header>

      <div className="container-x py-8">
        <nav className="mb-6 flex flex-wrap gap-2">
          {TABS.map((item) => (
            <Link
              key={item.key}
              href={`/admin?tab=${item.key}`}
              className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                tab === item.key ? "bg-plum text-cream" : "bg-white text-plum hover:bg-blush"
              }`}
            >
              {item.label}
              {item.key === "reviews" && pendingReviews ? (
                <span className="ml-1.5 rounded-full bg-gold px-1.5 text-[0.65rem] text-plum">
                  {pendingReviews}
                </span>
              ) : null}
            </Link>
          ))}
        </nav>

        {tab === "overview" && (
          <div className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { label: "Total bookings", value: stats.total.toString() },
                { label: "Pending", value: stats.pending.toString() },
                { label: "Confirmed", value: stats.confirmed.toString() },
                { label: "Booked value", value: formatMoney(stats.revenueCents) },
              ].map((card) => (
                <div key={card.label} className="card p-5">
                  <p className="text-xs uppercase tracking-widest text-plum-soft/60">{card.label}</p>
                  <p className="mt-1 font-display text-3xl font-bold text-plum">{card.value}</p>
                </div>
              ))}
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <div className="card p-6">
                <h2 className="font-display text-xl font-bold text-plum">Next up today</h2>
                {today.length ? (
                  <ul className="mt-4 space-y-2 text-sm">
                    {today.map((booking) => (
                      <li
                        key={booking.id}
                        className="flex items-center justify-between gap-3 border-b border-plum/8 pb-2 last:border-0"
                      >
                        <span>
                          <strong className="text-ink">{prettyTime(booking.bookingTime)}</strong>{" "}
                          <span className="text-plum-soft">
                            {booking.customerName} — {booking.serviceName}
                          </span>
                        </span>
                        <span className="text-xs font-semibold uppercase text-rose-dark">
                          {booking.status}
                        </span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="mt-3 text-sm text-plum-soft">No bookings for today yet.</p>
                )}
              </div>

              <div className="card p-6">
                <h2 className="font-display text-xl font-bold text-plum">Connection status</h2>
                <dl className="mt-4 space-y-2 text-sm">
                  <div className="flex justify-between gap-3">
                    <dt className="text-plum-soft">Database</dt>
                    <dd className="font-mono text-xs text-emerald-700">connected ✓</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="text-plum-soft">Driver</dt>
                    <dd className="text-ink">Drizzle ORM (node-postgres)</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="text-plum-soft">DATABASE_URL</dt>
                    <dd className="max-w-[16rem] truncate font-mono text-xs text-ink">
                      {maskDatabaseUrl(process.env.DATABASE_URL)}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="text-plum-soft">Supabase Storage</dt>
                    <dd className="text-ink">
                      {isSupabaseConfigured()
                        ? (getSupabaseProjectUrl() ?? "configured")
                        : "not configured (local /public images in use)"}
                    </dd>
                  </div>
                </dl>
                <p className="mt-4 rounded-xl bg-blush/70 p-3 text-xs leading-relaxed text-plum-soft">
                  To go live on Supabase, set <code className="font-mono">DATABASE_URL</code> to your
                  Supabase connection string and run <code className="font-mono">npx drizzle-kit push</code>.
                  The schema and seed data will apply automatically.
                </p>
              </div>
            </div>
          </div>
        )}

        {tab === "today" && <AdminBookings bookings={today} />}
        {tab === "bookings" && <AdminBookings bookings={allBookings} />}
        {tab === "reviews" && <AdminReviews reviews={allReviews} />}
        {tab === "messages" && <AdminMessages messages={messages} />}
      </div>
    </div>
  );
}


