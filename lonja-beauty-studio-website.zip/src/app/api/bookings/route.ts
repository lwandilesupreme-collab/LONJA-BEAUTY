import { NextResponse } from "next/server";

import { isValidISODate, todayISO } from "@/lib/booking";
import { createBooking, getAvailability, BookingError, getServiceById } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const date = url.searchParams.get("date") ?? todayISO();
  const serviceId = Number(url.searchParams.get("serviceId") ?? 0);

  if (!isValidISODate(date)) {
    return NextResponse.json({ ok: false, error: "Invalid date." }, { status: 400 });
  }

  const service = serviceId ? await getServiceById(serviceId) : null;
  const slots = await getAvailability(date, service?.durationMinutes ?? 60);
  return NextResponse.json({
    ok: true,
    date,
    durationMinutes: service?.durationMinutes ?? 60,
    slots,
  });
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;

    const customerName = String(body.customerName ?? "").trim();
    const customerPhone = String(body.customerPhone ?? "").trim();
    const serviceId = Number(body.serviceId ?? 0);
    const bookingDate = String(body.bookingDate ?? "");
    const bookingTime = String(body.bookingTime ?? "");

    if (customerName.length < 2) {
      return NextResponse.json({ ok: false, error: "Please enter your name." }, { status: 400 });
    }
    if (customerPhone.replace(/\D/g, "").length < 9) {
      return NextResponse.json(
        { ok: false, error: "Please enter a valid contact number." },
        { status: 400 },
      );
    }
    if (!serviceId) {
      return NextResponse.json({ ok: false, error: "Please choose a service." }, { status: 400 });
    }
    if (!isValidISODate(bookingDate)) {
      return NextResponse.json({ ok: false, error: "Please choose a date." }, { status: 400 });
    }
    if (!/^\d{2}:\d{2}$/.test(bookingTime)) {
      return NextResponse.json({ ok: false, error: "Please choose a time." }, { status: 400 });
    }

    const rawAddOns = Array.isArray(body.addOns) ? body.addOns : [];
    const addOns = rawAddOns
      .map((item) => {
        const record = item as { name?: unknown; priceCents?: unknown };
        return {
          name: String(record.name ?? ""),
          priceCents: Number(record.priceCents ?? 0),
        };
      })
      .filter((item) => item.name);

    const booking = await createBooking({
      customerName,
      customerPhone,
      customerEmail: body.customerEmail ? String(body.customerEmail).trim() : null,
      serviceId,
      addOns,
      technicianId: body.technicianId ? Number(body.technicianId) : null,
      bookingDate,
      bookingTime,
      notes: body.notes ? String(body.notes).trim() : null,
    });

    return NextResponse.json({ ok: true, booking }, { status: 201 });
  } catch (error) {
    if (error instanceof BookingError) {
      return NextResponse.json({ ok: false, error: error.message }, { status: 409 });
    }
    console.error("booking failed", error);
    return NextResponse.json(
      { ok: false, error: "Something went wrong saving your booking. Please try again." },
      { status: 500 },
    );
  }
}
