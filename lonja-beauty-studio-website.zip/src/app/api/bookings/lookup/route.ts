import { NextResponse } from "next/server";

import { normalizePhone } from "@/lib/booking";
import { findBookingsByPhone, getBookingByReference } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const reference = url.searchParams.get("reference");
  const phone = url.searchParams.get("phone");

  if (reference) {
    const booking = await getBookingByReference(reference);
    if (!booking) {
      return NextResponse.json(
        { ok: false, error: "No booking found with that reference." },
        { status: 404 },
      );
    }
    return NextResponse.json({ ok: true, bookings: [booking] });
  }

  if (phone) {
    const normalised = normalizePhone(phone);
    const results = await findBookingsByPhone(normalised);
    if (!results.length) {
      return NextResponse.json(
        { ok: false, error: "No bookings found for that number." },
        { status: 404 },
      );
    }
    return NextResponse.json({ ok: true, bookings: results });
  }

  return NextResponse.json(
    { ok: false, error: "Provide a booking reference or your phone number." },
    { status: 400 },
  );
}
