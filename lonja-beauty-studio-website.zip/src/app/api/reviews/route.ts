import { NextResponse } from "next/server";

import { createReview } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const authorName = String(body.authorName ?? "").trim();
    const text = String(body.body ?? "").trim();
    const rating = Math.min(5, Math.max(1, Number(body.rating ?? 5)));

    if (authorName.length < 2) {
      return NextResponse.json({ ok: false, error: "Please add your name." }, { status: 400 });
    }
    if (text.length < 10) {
      return NextResponse.json(
        { ok: false, error: "Please write at least a sentence about your visit." },
        { status: 400 },
      );
    }

    await createReview({
      authorName,
      rating,
      serviceTag: body.serviceTag ? String(body.serviceTag) : null,
      technicianName: body.technicianName ? String(body.technicianName) : null,
      body: text,
    });

    return NextResponse.json({ ok: true }, { status: 201 });
  } catch (error) {
    console.error("review failed", error);
    return NextResponse.json({ ok: false, error: "Could not save your review." }, { status: 500 });
  }
}
