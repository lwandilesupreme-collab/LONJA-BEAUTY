import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";

import { db } from "@/db";
import { reviews } from "@/db/schema";
import { isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await isAdmin())) {
    return NextResponse.json({ ok: false, error: "Unauthorised" }, { status: 401 });
  }

  const { id } = await params;
  const reviewId = Number(id);
  const body = (await request.json()) as { isApproved?: boolean; ownerReply?: string };

  const rows = await db
    .update(reviews)
    .set({
      ...(typeof body.isApproved === "boolean" ? { isApproved: body.isApproved } : {}),
      ...(typeof body.ownerReply === "string" ? { ownerReply: body.ownerReply } : {}),
    })
    .where(eq(reviews.id, reviewId))
    .returning();

  if (!rows[0]) {
    return NextResponse.json({ ok: false, error: "Review not found" }, { status: 404 });
  }
  return NextResponse.json({ ok: true, review: rows[0] });
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await isAdmin())) {
    return NextResponse.json({ ok: false, error: "Unauthorised" }, { status: 401 });
  }
  const { id } = await params;
  await db.delete(reviews).where(eq(reviews.id, Number(id)));
  return NextResponse.json({ ok: true });
}
