import { NextResponse } from "next/server";

import { BOOKING_STATUSES } from "@/lib/booking";
import { isAdmin } from "@/lib/auth";
import { deleteBooking, updateBookingStatus } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await isAdmin())) {
    return NextResponse.json({ ok: false, error: "Unauthorised" }, { status: 401 });
  }

  const { id } = await params;
  const bookingId = Number(id);
  if (!Number.isFinite(bookingId)) {
    return NextResponse.json({ ok: false, error: "Invalid booking id" }, { status: 400 });
  }

  const body = (await request.json()) as { status?: string };
  const status = String(body.status ?? "");
  if (!BOOKING_STATUSES.includes(status as (typeof BOOKING_STATUSES)[number])) {
    return NextResponse.json({ ok: false, error: "Invalid status" }, { status: 400 });
  }

  const booking = await updateBookingStatus(bookingId, status);
  if (!booking) {
    return NextResponse.json({ ok: false, error: "Booking not found" }, { status: 404 });
  }
  return NextResponse.json({ ok: true, booking });
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await isAdmin())) {
    return NextResponse.json({ ok: false, error: "Unauthorised" }, { status: 401 });
  }
  const { id } = await params;
  await deleteBooking(Number(id));
  return NextResponse.json({ ok: true });
}
