import { NextResponse } from "next/server";

import { createMessage } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = String(body.name ?? "").trim();
    const text = String(body.body ?? "").trim();

    if (name.length < 2) {
      return NextResponse.json({ ok: false, error: "Please add your name." }, { status: 400 });
    }
    if (text.length < 5) {
      return NextResponse.json({ ok: false, error: "Please add a message." }, { status: 400 });
    }

    await createMessage({
      name,
      phone: body.phone ? String(body.phone).trim() : null,
      email: body.email ? String(body.email).trim() : null,
      subject: body.subject ? String(body.subject).trim() : null,
      body: text,
    });

    return NextResponse.json({ ok: true }, { status: 201 });
  } catch (error) {
    console.error("message failed", error);
    return NextResponse.json({ ok: false, error: "Could not send your message." }, { status: 500 });
  }
}
