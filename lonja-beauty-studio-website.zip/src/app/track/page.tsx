"use client";

import Link from "next/link";
import { useState } from "react";

import type { Booking } from "@/db/schema";
import { STATUS_LABEL, STATUS_STYLE, prettyDate, prettyTime } from "@/lib/booking";
import { formatDuration, formatMoney, SITE } from "@/lib/site";

export default function TrackPage() {
  const [query, setQuery] = useState("");
  const [bookings, setBookings] = useState<Booking[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function search(event: React.FormEvent) {
    event.preventDefault();
    setLoading(true);
    setError(null);
    setBookings(null);
    try {
      const trimmed = query.trim();
      const isReference = /^lb-/i.test(trimmed);
      const params = isReference
        ? `reference=${encodeURIComponent(trimmed)}`
        : `phone=${encodeURIComponent(trimmed)}`;
      const response = await fetch(`/api/bookings/lookup?${params}`, { cache: "no-store" });
      const data = (await response.json()) as { ok: boolean; bookings?: Booking[]; error?: string };
      if (!data.ok) {
        setError(data.error ?? "Nothing found.");
        return;
      }
      setBookings(data.bookings ?? []);
    } catch {
      setError("Network error — please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="bg-gradient-to-b from-blush/60 to-cream py-14">
      <div className="container-x max-w-3xl">
        <div className="text-center">
          <p className="eyebrow">Booking lookup</p>
          <h1 className="mt-2 font-display text-4xl font-bold text-plum">Find my booking</h1>
          <p className="mt-3 text-sm text-plum-soft">
            Enter the reference we gave you (starts with <strong>LB-</strong>) or the mobile number
            you booked with.
          </p>
        </div>

        <form onSubmit={search} className="card mt-8 flex flex-col gap-3 p-5 sm:flex-row">
          <input
            className="field"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="LB-XXXXXX or 073 086 6933"
            aria-label="Booking reference or phone number"
          />
          <button type="submit" className="btn btn-primary shrink-0" disabled={loading}>
            {loading ? "Searching…" : "Find booking"}
          </button>
        </form>

        {error ? (
          <div className="card mt-6 p-6 text-center">
            <p className="font-display text-xl font-bold text-plum">Hmm, nothing came up</p>
            <p className="mt-2 text-sm text-plum-soft">{error}</p>
            <p className="mt-4 text-sm text-plum-soft">
              Call us on{" "}
              <a href={`tel:${SITE.phoneTel}`} className="font-semibold underline">
                {SITE.phoneDisplay}
              </a>{" "}
              and we&apos;ll sort it out.
            </p>
          </div>
        ) : null}

        {bookings?.length ? (
          <div className="mt-8 space-y-4">
            {bookings.map((booking) => (
              <article key={booking.id} className="card p-6">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="font-display text-xl font-bold text-plum">{booking.serviceName}</p>
                    <p className="text-sm text-plum-soft">
                      {prettyDate(booking.bookingDate)} at {prettyTime(booking.bookingTime)} ·{" "}
                      {formatDuration(booking.durationMinutes)}
                    </p>
                  </div>
                  <span
                    className={`rounded-full px-3 py-1 text-xs font-semibold ring-1 ${
                      STATUS_STYLE[booking.status] ?? "bg-stone-100 text-stone-700 ring-stone-200"
                    }`}
                  >
                    {STATUS_LABEL[booking.status] ?? booking.status}
                  </span>
                </div>

                <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-3">
                  <div>
                    <dt className="text-xs uppercase tracking-wider text-plum-soft/60">Reference</dt>
                    <dd className="font-semibold text-ink">{booking.reference}</dd>
                  </div>
                  <div>
                    <dt className="text-xs uppercase tracking-wider text-plum-soft/60">Tech</dt>
                    <dd className="font-semibold text-ink">
                      {booking.technicianName ?? "First available"}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs uppercase tracking-wider text-plum-soft/60">Total</dt>
                    <dd className="font-semibold text-ink">{formatMoney(booking.totalCents)}</dd>
                  </div>
                </dl>

                {booking.addOns?.length ? (
                  <p className="mt-3 text-xs text-plum-soft">
                    Add-ons: {booking.addOns.map((item) => item.name).join(", ")}
                  </p>
                ) : null}

                <div className="mt-5 flex flex-wrap gap-2">
                  <a
                    href={`https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(
                      `Hi Lonja! I'd like to change my booking ${booking.reference}.`,
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="btn btn-ghost !py-2 !px-4 text-xs"
                  >
                    Request a change
                  </a>
                  <a
                    href={`https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(
                      `Hi Lonja! Cancelling booking ${booking.reference}, sorry!`,
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="btn !py-2 !px-4 text-xs text-rose-700 hover:bg-rose-50"
                  >
                    Cancel booking
                  </a>
                </div>
              </article>
            ))}
          </div>
        ) : null}

        {!bookings && !error ? (
          <div className="card mt-8 p-8 text-center">
            <p className="text-sm text-plum-soft">
              Haven&apos;t booked yet?{" "}
              <Link href="/book" className="font-semibold text-plum underline">
                Book your appointment here
              </Link>
              .
            </p>
          </div>
        ) : null}
      </div>
    </div>
  );
}
