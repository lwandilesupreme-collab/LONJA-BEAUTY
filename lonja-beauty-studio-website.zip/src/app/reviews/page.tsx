import Link from "next/link";
import type { Metadata } from "next";

import { ReviewForm } from "@/components/review-form";
import { ReviewCard, SectionHeading, Stars } from "@/components/ui";
import { getReviews, getTechnicians } from "@/lib/data";
import { SITE } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Client Reviews",
  description:
    "Read what clients say about Lonja Beauty Studio Fourways — real Google reviews about our nail techs, lash techs and stylists.",
};

export default async function ReviewsPage() {
  const [reviews, techs] = await Promise.all([getReviews(), getTechnicians()]);

  const average =
    reviews.length > 0
      ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length
      : SITE.rating;

  const buckets = [5, 4, 3, 2, 1].map((star) => ({
    star,
    count: reviews.filter((review) => review.rating === star).length,
  }));

  const mentions = Array.from(
    new Set(reviews.map((review) => review.technicianName).filter(Boolean) as string[]),
  );

  return (
    <div className="bg-cream py-12">
      <div className="container-x">
        <SectionHeading
          eyebrow="Reviews"
          title="What Fourways says about us"
          description="These are real reviews left on our Google Business profile. We reply to every one — the praise and the complaints."
        />

        <div className="card mt-10 grid gap-8 p-6 sm:p-8 lg:grid-cols-[auto_1fr]">
          <div className="text-center lg:border-r lg:border-plum/10 lg:pr-8">
            <p className="font-display text-6xl font-bold text-plum">{average.toFixed(1)}</p>
            <Stars rating={average} className="text-lg" />
            <p className="mt-1 text-sm text-plum-soft">
              {SITE.reviewCount} Google reviews
            </p>
            <p className="mt-3 text-xs text-plum-soft/70">
              {reviews.length} shown on this site
            </p>
          </div>

          <div className="space-y-2">
            {buckets.map((bucket) => {
              const percent = reviews.length
                ? Math.round((bucket.count / reviews.length) * 100)
                : 0;
              return (
                <div key={bucket.star} className="flex items-center gap-3 text-xs">
                  <span className="w-8 shrink-0 text-plum-soft">{bucket.star}★</span>
                  <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-plum/10">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-gold to-rose"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                  <span className="w-10 shrink-0 text-right text-plum-soft">{bucket.count}</span>
                </div>
              );
            })}
            {mentions.length ? (
              <p className="pt-3 text-xs text-plum-soft">
                Most mentioned techs:{" "}
                <span className="font-semibold text-plum">{mentions.slice(0, 5).join(", ")}</span>
              </p>
            ) : null}
          </div>
        </div>

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {reviews.map((review) => (
            <ReviewCard key={review.id} review={review} />
          ))}
        </div>

        <div id="write" className="mt-14 grid gap-8 lg:grid-cols-[1.3fr_1fr]">
          <div>
            <SectionHeading
              align="left"
              eyebrow="Write a review"
              title="Tell us how we did"
              description="Honest feedback helps us train the team and fix what isn't working. Reviews are moderated before publishing."
            />
            <div className="mt-6">
              <ReviewForm technicians={techs.map((tech) => tech.name)} />
            </div>
          </div>

          <aside className="card h-fit p-6">
            <p className="eyebrow">Something to fix?</p>
            <h3 className="mt-2 font-display text-2xl font-bold text-plum">
              We&apos;d rather hear it first
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-plum-soft/85">
              If a set didn&apos;t last, if you waited too long, or if a tech made you feel
              uncomfortable — tell the studio manager on the day or WhatsApp us. We&apos;ll make it
              right, whether that&apos;s a free refill, a repair or a redo.
            </p>
            <ul className="mt-4 space-y-2 text-sm text-plum-soft/85">
              <li>💅 Free repair within 7 days of your set</li>
              <li>⏱️ Booked clients are prioritised over walk-ins</li>
              <li>🧼 Hygiene concerns are escalated same-day</li>
            </ul>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/contact" className="btn btn-primary !py-2.5 text-sm">
                Message the manager
              </Link>
              <Link href="/book" className="btn btn-ghost !py-2.5 text-sm">
                Book again
              </Link>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
