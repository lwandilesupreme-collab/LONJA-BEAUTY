import Image from "next/image";
import Link from "next/link";

import { Pill, ReviewCard, SectionHeading, Stars } from "@/components/ui";
import { getGallery, getPopularServices, getReviews, getTechnicians } from "@/lib/data";
import { CATEGORY_META, CATEGORY_ORDER } from "@/lib/pricelist";
import { SITE, formatMoney, whatsappLink } from "@/lib/site";

export const dynamic = "force-dynamic";

const FEATURES = [
  {
    icon: "🧼",
    title: "Hospital-grade hygiene",
    body: "Tools sterilised between every client and each workstation cleaned after every application.",
  },
  {
    icon: "⏱️",
    title: "In & out on time",
    body: "Coloured acrylic buffed and sealed with a top coat — no long gel curing queues.",
  },
  {
    icon: "🎨",
    title: "Any design you bring",
    body: "Chrome, cat eye, ombre, 3D flowers and hand-painted art from R15 a nail.",
  },
  {
    icon: "☕",
    title: "Coffee on the house",
    body: "Complimentary coffee and juice while you get pampered — bring a friend.",
  },
];

export default async function HomePage() {
  const [services, reviews, techs, gallery] = await Promise.all([
    getPopularServices(6),
    getReviews(),
    getTechnicians(),
    getGallery(),
  ]);

  const featuredReviews = reviews.slice(0, 6);
  const galleryPreview = gallery.slice(0, 6);
  const nailTechs = techs.slice(0, 4);

  return (
    <>
      {/* ---------------------------------------------------------- HERO */}
      <section className="relative overflow-hidden bg-gradient-to-b from-blush via-cream to-cream">
        <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-rose-light/40 blur-3xl" />
        <div className="pointer-events-none absolute -left-20 top-40 h-64 w-64 rounded-full bg-gold/20 blur-3xl" />

        <div className="container-x relative grid items-center gap-12 py-14 lg:grid-cols-[1.05fr_1fr] lg:py-20">
          <div className="animate-fade-up">
            <div className="flex flex-wrap items-center gap-3">
              <Pill tone="plum">💅 Nails · Lashes · Hair</Pill>
              <span className="flex items-center gap-2 text-xs text-plum-soft">
                <Stars rating={SITE.rating} className="text-sm" />
                {SITE.rating} · {SITE.reviewCount} Google reviews
              </span>
            </div>

            <h1 className="mt-5 font-display text-4xl font-bold leading-[1.05] text-plum sm:text-5xl lg:text-6xl">
              Fourways&apos; favourite
              <span className="block bg-gradient-to-r from-rose-dark via-plum to-rose bg-clip-text text-transparent">
                nail tech studio
              </span>
            </h1>

            <p className="mt-5 max-w-xl text-base leading-relaxed text-plum-soft">
              Acrylics, gel, polygel, cat eye and 3D art — plus lashes, braids and blow outs, all
              under one roof at <strong className="text-plum">264 Pritchard Street</strong>. Open
              seven days a week, 9am to 6pm.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link href="/book" className="btn btn-primary">
                Book your appointment
              </Link>
              <Link href="/services" className="btn btn-ghost">
                View the pricelist
              </Link>
              <a
                href={whatsappLink("Hi Lonja Beauty Studio Fourways! Do you have availability today?")}
                target="_blank"
                rel="noreferrer"
                className="btn !px-4 !py-2.5 text-sm font-semibold text-emerald-700 hover:bg-emerald-50"
              >
                💬 Ask on WhatsApp
              </a>
            </div>

            <dl className="mt-10 grid max-w-lg grid-cols-3 gap-4 border-t border-plum/10 pt-6">
              {[
                { k: "7 days", v: "Open every week" },
                { k: "150+", v: "Services on the menu" },
                { k: "181", v: "Client reviews" },
              ].map((item) => (
                <div key={item.k}>
                  <dt className="font-display text-2xl font-bold text-plum">{item.k}</dt>
                  <dd className="text-xs text-plum-soft/75">{item.v}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative">
            <div className="relative overflow-hidden rounded-[2rem] border border-white/60 shadow-soft">
              <Image
                src="/images/hero.jpg"
                alt="Blush pink acrylic nails with gold chrome accents at Lonja Beauty Studio Fourways"
                width={900}
                height={1100}
                priority
                className="h-[420px] w-full object-cover sm:h-[520px]"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-plum/85 to-transparent p-5 pt-16">
                <p className="font-display text-xl font-semibold text-cream">
                  Today&apos;s most-booked set
                </p>
                <p className="text-sm text-cream/80">
                  Almond acrylic · blush pink · gold chrome from {formatMoney(19000)}
                </p>
              </div>
            </div>
            <div className="absolute -bottom-6 -left-4 hidden rounded-2xl bg-white p-4 shadow-soft sm:block">
              <p className="text-[0.65rem] uppercase tracking-widest text-rose-dark">Walk-ins</p>
              <p className="font-display text-lg font-bold text-plum">Welcome</p>
              <p className="text-xs text-plum-soft/70">Buff &amp; shine R130</p>
            </div>
          </div>
        </div>
      </section>

      {/* ------------------------------------------------- POPULAR SERVICES */}
      <section className="container-x py-16">
        <SectionHeading
          eyebrow="Most requested"
          title="What Fourways books us for"
          description="Real prices, no surprises. Soak-offs and art are quoted separately so you always know the final number."
        />
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <Link
              key={service.id}
              href={`/book?service=${service.id}`}
              className="card group p-5 transition hover:-translate-y-1 hover:shadow-soft"
            >
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-display text-xl font-semibold text-plum">{service.name}</h3>
                <span className="font-display text-lg font-bold text-rose-dark">
                  {service.priceLabel ?? formatMoney(service.priceCents)}
                </span>
              </div>
              <p className="mt-2 text-sm leading-relaxed text-plum-soft/85">
                {service.description ?? `${service.category} service by our senior team.`}
              </p>
              <p className="mt-4 text-xs font-semibold uppercase tracking-widest text-rose-dark group-hover:underline">
                Book this →
              </p>
            </Link>
          ))}
        </div>
        <div className="mt-8 text-center">
          <Link href="/services" className="btn btn-ghost">
            See all 150+ services &amp; prices
          </Link>
        </div>
      </section>

      {/* ------------------------------------------------------- CATEGORIES */}
      <section className="bg-plum py-16 text-cream">
        <div className="container-x">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-[0.7rem] uppercase tracking-[0.22em] text-rose-light">
              One studio, four services
            </p>
            <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">
              Get the whole look done in one visit
            </h2>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {CATEGORY_ORDER.map((category) => (
              <Link
                key={category}
                href={`/services?category=${encodeURIComponent(category)}`}
                className="group rounded-2xl border border-cream/15 bg-cream/5 p-5 transition hover:border-rose-light hover:bg-cream/10"
              >
                <span className="text-3xl">{CATEGORY_META[category].icon}</span>
                <h3 className="mt-3 font-display text-xl font-semibold">
                  {CATEGORY_META[category].label}
                </h3>
                <p className="mt-1.5 text-xs leading-relaxed text-cream/70">
                  {CATEGORY_META[category].blurb}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* --------------------------------------------------------- FEATURES */}
      <section className="container-x grid items-center gap-12 py-16 lg:grid-cols-2">
        <div className="overflow-hidden rounded-[2rem] shadow-soft">
          <Image
            src="/images/studio.jpg"
            alt="Inside Lonja Beauty Studio Fourways"
            width={1000}
            height={750}
            className="h-full w-full object-cover"
          />
        </div>
        <div>
          <SectionHeading
            align="left"
            eyebrow="Why clients come back"
            title="A studio that treats your nails like art"
            description="We keep it clean, we keep it quick, and we keep it friendly. That's what 181 reviewers keep telling us."
          />
          <div className="mt-8 grid gap-5 sm:grid-cols-2">
            {FEATURES.map((feature) => (
              <div key={feature.title}>
                <span className="text-2xl">{feature.icon}</span>
                <h3 className="mt-2 font-semibold text-plum">{feature.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-plum-soft/80">{feature.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------------- GALLERY */}
      <section className="bg-blush/60 py-16">
        <div className="container-x">
          <SectionHeading
            eyebrow="Fresh from the chair"
            title="Recent sets from our studio"
            description="Follow the vibe — every set is shaped, coloured and finished to suit your hands."
          />
          <div className="mt-10 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3">
            {galleryPreview.map((item) => (
              <div key={item.id} className="group relative overflow-hidden rounded-2xl">
                <Image
                  src={item.imageUrl}
                  alt={item.title}
                  width={700}
                  height={700}
                  className="h-52 w-full object-cover transition duration-500 group-hover:scale-105 sm:h-72"
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-plum/85 to-transparent p-3 pt-10">
                  <p className="text-sm font-semibold text-cream">{item.title}</p>
                  {item.technicianName ? (
                    <p className="text-[0.7rem] text-cream/75">by {item.technicianName}</p>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-8 text-center">
            <Link href="/gallery" className="btn btn-primary">
              Open the full gallery
            </Link>
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------ REVIEWS */}
      <section className="container-x py-16">
        <SectionHeading
          eyebrow="Client love"
          title="Straight from our Google reviews"
          description="We read every single one — and we reply. Here's what clients say about working with our techs."
        />
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {featuredReviews.map((review) => (
            <ReviewCard key={review.id} review={review} />
          ))}
        </div>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link href="/reviews" className="btn btn-ghost">
            Read all reviews
          </Link>
          <Link href="/reviews#write" className="btn btn-primary">
            Write a review
          </Link>
        </div>
      </section>

      {/* -------------------------------------------------------------- TEAM */}
      <section className="bg-plum py-16 text-cream">
        <div className="container-x">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-[0.7rem] uppercase tracking-[0.22em] text-rose-light">The team</p>
            <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">
              Ask for your favourite tech by name
            </h2>
            <p className="mt-3 text-sm text-cream/75">
              Mafusi, Thato, Precious and Sne are on the floor all week. You can request a specific
              tech when you book online.
            </p>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {nailTechs.map((tech) => (
              <div
                key={tech.id}
                className="rounded-2xl border border-cream/15 bg-cream/5 p-5 text-center"
              >
                <span
                  className="mx-auto grid h-16 w-16 place-items-center rounded-full font-display text-xl font-bold text-white"
                  style={{ background: tech.accentColor }}
                >
                  {tech.initials}
                </span>
                <h3 className="mt-3 font-display text-xl font-semibold">{tech.name}</h3>
                <p className="text-[0.7rem] uppercase tracking-widest text-rose-light">
                  {tech.role}
                </p>
                <p className="mt-2 text-xs leading-relaxed text-cream/70">{tech.specialties}</p>
              </div>
            ))}
          </div>
          <div className="mt-8 text-center">
            <Link href="/team" className="btn btn-gold">
              Meet the whole team
            </Link>
          </div>
        </div>
      </section>

      {/* -------------------------------------------------------- HOURS + CTA */}
      <section className="container-x py-16">
        <div className="card grid overflow-hidden lg:grid-cols-[1fr_1.1fr]">
          <div className="p-8 sm:p-10">
            <p className="eyebrow">Find us</p>
            <h2 className="mt-2 font-display text-3xl font-bold text-plum">
              {SITE.address.street}
            </h2>
            <p className="mt-1 text-plum-soft">
              {SITE.address.area}, {SITE.address.city} {SITE.address.code}
            </p>
            <p className="mt-2 text-xs text-plum-soft/60">Plus code {SITE.plusCode}</p>

            <ul className="mt-6 space-y-1.5 text-sm">
              <li className="flex justify-between border-b border-plum/8 pb-1.5">
                <span className="text-plum-soft">Monday – Friday</span>
                <span className="font-medium text-ink">9:00 am – 6:00 pm</span>
              </li>
              <li className="flex justify-between border-b border-plum/8 pb-1.5">
                <span className="text-plum-soft">Saturday</span>
                <span className="font-medium text-ink">9:00 am – 6:00 pm</span>
              </li>
              <li className="flex justify-between">
                <span className="text-plum-soft">Sunday</span>
                <span className="font-medium text-ink">9:00 am – 6:00 pm</span>
              </li>
            </ul>

            <div className="mt-7 flex flex-wrap gap-3">
              <a href={`tel:${SITE.phoneTel}`} className="btn btn-primary">
                📞 {SITE.phoneDisplay}
              </a>
              <a
                href={SITE.mapsDirections}
                target="_blank"
                rel="noreferrer"
                className="btn btn-ghost"
              >
                Directions
              </a>
            </div>
          </div>
          <div className="min-h-[320px] bg-sand">
            <iframe
              title="Map to Lonja Beauty Studio Fourways"
              src={SITE.mapsEmbed}
              className="h-full min-h-[320px] w-full border-0"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>

      {/* --------------------------------------------------------- FINAL CTA */}
      <section className="container-x pb-8">
        <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-r from-plum via-plum-soft to-rose-dark px-8 py-14 text-center text-cream">
          <div className="pointer-events-none absolute inset-0 opacity-20 [background:radial-gradient(circle_at_20%_20%,white,transparent_45%)]" />
          <h2 className="relative font-display text-3xl font-bold sm:text-4xl">
            Your next set is one tap away
          </h2>
          <p className="relative mx-auto mt-3 max-w-xl text-sm text-cream/85">
            Pick your service, choose your tech and lock in a time. No deposit needed — we confirm on
            WhatsApp during business hours.
          </p>
          <div className="relative mt-8 flex flex-wrap justify-center gap-3">
            <Link href="/book" className="btn bg-cream text-plum hover:bg-white">
              Book online now
            </Link>
            <Link href="/track" className="btn border border-cream/40 text-cream hover:bg-cream/10">
              Find my booking
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
