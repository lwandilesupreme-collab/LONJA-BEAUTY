import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";

import { SectionHeading } from "@/components/ui";
import { getReviews, getTechnicians } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Our Nail Techs & Stylists",
  description:
    "Meet the Lonja Beauty Studio Fourways team — Mafusi, Thato, Precious, Sne, Natasha and Lesego. Request your favourite nail tech when you book online.",
};

export default async function TeamPage() {
  const [techs, reviews] = await Promise.all([getTechnicians(), getReviews()]);

  return (
    <div className="bg-cream py-12">
      <div className="container-x">
        <SectionHeading
          eyebrow="The team"
          title="Meet your nail techs"
          description="Our clients come back for specific techs by name. Here's who's who on the floor — you can request any of them during online booking."
        />

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {techs.map((tech) => {
            const shoutOuts = reviews.filter(
              (review) =>
                review.technicianName &&
                tech.name.toLowerCase().includes(review.technicianName.toLowerCase()),
            );
            return (
              <article key={tech.id} className="card overflow-hidden">
                <div
                  className="h-28 w-full"
                  style={{
                    background: `linear-gradient(120deg, ${tech.accentColor}, #4a1f2c)`,
                  }}
                />
                <div className="p-6">
                  <span
                    className="-mt-14 grid h-16 w-16 place-items-center rounded-full border-4 border-white font-display text-xl font-bold text-white shadow-soft"
                    style={{ background: tech.accentColor }}
                  >
                    {tech.initials}
                  </span>
                  <h2 className="mt-3 font-display text-2xl font-bold text-plum">{tech.name}</h2>
                  <p className="text-xs uppercase tracking-widest text-rose-dark">{tech.role}</p>
                  <p className="mt-3 text-sm leading-relaxed text-plum-soft/85">{tech.bio}</p>
                  <p className="mt-4 text-xs font-semibold text-plum">Specialises in</p>
                  <p className="text-sm text-plum-soft/85">{tech.specialties}</p>
                  {shoutOuts.length ? (
                    <div className="mt-4 rounded-xl bg-blush/70 p-3 text-xs text-plum-soft">
                      ⭐ {shoutOuts.length} client shout-out
                      {shoutOuts.length === 1 ? "" : "s"} on Google
                    </div>
                  ) : null}
                  <Link
                    href="/book"
                    className="btn btn-ghost mt-5 w-full !py-2.5 text-sm"
                    aria-label={`Book with ${tech.name}`}
                  >
                    Book with {tech.name}
                  </Link>
                </div>
              </article>
            );
          })}
        </div>

        <div className="card mt-12 grid items-center gap-8 overflow-hidden lg:grid-cols-2">
          <Image
            src="/images/studio.jpg"
            alt="Lonja Beauty Studio Fourways interior"
            width={1000}
            height={750}
            className="h-full w-full object-cover"
          />
          <div className="p-8 sm:p-10">
            <p className="eyebrow">Join us</p>
            <h2 className="mt-2 font-display text-3xl font-bold text-plum">
              We&apos;re always looking for talent
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-plum-soft/85">
              Qualified nail techs, lash techs and stylists — send your portfolio and we&apos;ll be in
              touch. We offer a clean, busy studio, product supplied and commission on retail.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/contact" className="btn btn-primary">
                Send your portfolio
              </Link>
              <Link href="/book" className="btn btn-ghost">
                Book a visit
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
