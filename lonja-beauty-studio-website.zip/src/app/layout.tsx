import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { FloatingActions } from "@/components/floating-actions";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  title: {
    default: `${SITE.fullName} — Nail Tech in Fourways, Johannesburg`,
    template: `%s | ${SITE.fullName}`,
  },
  description: SITE.description,
  keywords: [
    "nail tech Fourways",
    "nails Johannesburg",
    "acrylic nails Fourways",
    "beauty salon Fourways",
    "gel nails Sandton",
    "eyelash extensions Fourways",
    "Lonja Beauty Studio",
  ],
  openGraph: {
    title: `${SITE.fullName} — Nail Tech in Fourways`,
    description: SITE.description,
    type: "website",
    locale: "en_ZA",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en-ZA">
      <body className="bg-cream text-ink antialiased">
        <SiteHeader />
        <main className="min-h-[60vh]">{children}</main>
        <SiteFooter />
        <FloatingActions />
      </body>
    </html>
  );
}
