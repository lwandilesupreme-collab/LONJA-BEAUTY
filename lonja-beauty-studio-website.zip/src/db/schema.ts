import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

/* -------------------------------------------------------------------------- */
/*  Services (the full Lonja pricelist)                                       */
/* -------------------------------------------------------------------------- */

export const services = pgTable(
  "services",
  {
    id: serial("id").primaryKey(),
    slug: varchar("slug", { length: 140 }).notNull().unique(),
    name: varchar("name", { length: 180 }).notNull(),
    /** Nails | Eyelashes | Hair | Hair Cuts | Kids */
    category: varchar("category", { length: 80 }).notNull(),
    /** e.g. Knotless Braids, Relaxer, General */
    subcategory: varchar("subcategory", { length: 100 }),
    description: text("description"),
    priceCents: integer("price_cents").notNull(),
    /** For variable pricing e.g. "Starts @ R450" */
    priceLabel: varchar("price_label", { length: 80 }),
    durationMinutes: integer("duration_minutes").notNull().default(60),
    isPopular: boolean("is_popular").notNull().default(false),
    isActive: boolean("is_active").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("services_category_idx").on(table.category)],
);

/* -------------------------------------------------------------------------- */
/*  Nail techs / stylists on the floor                                        */
/* -------------------------------------------------------------------------- */

export const technicians = pgTable("technicians", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  role: varchar("role", { length: 120 }).notNull().default("Nail Technician"),
  specialties: text("specialties"),
  bio: text("bio"),
  initials: varchar("initials", { length: 4 }).notNull().default("LB"),
  accentColor: varchar("accent_color", { length: 24 })
    .notNull()
    .default("#B76E79"),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

/* -------------------------------------------------------------------------- */
/*  Bookings                                                                  */
/* -------------------------------------------------------------------------- */

export const bookings = pgTable(
  "bookings",
  {
    id: serial("id").primaryKey(),
    reference: varchar("reference", { length: 20 }).notNull().unique(),
    customerName: varchar("customer_name", { length: 160 }).notNull(),
    customerPhone: varchar("customer_phone", { length: 40 }).notNull(),
    customerEmail: varchar("customer_email", { length: 200 }),
    serviceId: integer("service_id").references(() => services.id, {
      onDelete: "set null",
    }),
    serviceName: varchar("service_name", { length: 200 }).notNull(),
    serviceCategory: varchar("service_category", { length: 80 })
      .notNull()
      .default("Nails"),
    /** [{ name, priceCents }] */
    addOns: jsonb("add_ons").$type<{ name: string; priceCents: number }[]>(),
    technicianId: integer("technician_id").references(() => technicians.id, {
      onDelete: "set null",
    }),
    technicianName: varchar("technician_name", { length: 120 }),
    bookingDate: date("booking_date").notNull(),
    bookingTime: varchar("booking_time", { length: 5 }).notNull(),
    durationMinutes: integer("duration_minutes").notNull().default(60),
    totalCents: integer("total_cents").notNull().default(0),
    notes: text("notes"),
    /** pending | confirmed | completed | cancelled | no_show */
    status: varchar("status", { length: 20 }).notNull().default("pending"),
    adminNote: text("admin_note"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("bookings_date_idx").on(table.bookingDate),
    index("bookings_status_idx").on(table.status),
    index("bookings_phone_idx").on(table.customerPhone),
  ],
);

/* -------------------------------------------------------------------------- */
/*  Reviews (Google imports + website submissions)                            */
/* -------------------------------------------------------------------------- */

export const reviews = pgTable(
  "reviews",
  {
    id: serial("id").primaryKey(),
    authorName: varchar("author_name", { length: 160 }).notNull(),
    authorMeta: varchar("author_meta", { length: 200 }),
    rating: integer("rating").notNull().default(5),
    serviceTag: varchar("service_tag", { length: 120 }),
    technicianName: varchar("technician_name", { length: 120 }),
    body: text("body").notNull(),
    /** google | website */
    source: varchar("source", { length: 20 }).notNull().default("website"),
    isApproved: boolean("is_approved").notNull().default(false),
    ownerReply: text("owner_reply"),
    reviewDate: varchar("review_date", { length: 40 }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("reviews_approved_idx").on(table.isApproved)],
);

/* -------------------------------------------------------------------------- */
/*  Gallery                                                                   */
/* -------------------------------------------------------------------------- */

export const galleryItems = pgTable("gallery_items", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 160 }).notNull(),
  category: varchar("category", { length: 80 }).notNull().default("Nails"),
  imageUrl: text("image_url").notNull(),
  technicianName: varchar("technician_name", { length: 120 }),
  isFeatured: boolean("is_featured").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

/* -------------------------------------------------------------------------- */
/*  Contact / enquiry messages                                                */
/* -------------------------------------------------------------------------- */

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  phone: varchar("phone", { length: 40 }),
  email: varchar("email", { length: 200 }),
  subject: varchar("subject", { length: 200 }),
  body: text("body").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

/* -------------------------------------------------------------------------- */
/*  Editable site settings (hours, announcement bar, etc.)                    */
/* -------------------------------------------------------------------------- */

export const siteSettings = pgTable("site_settings", {
  key: varchar("key", { length: 80 }).primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Service = typeof services.$inferSelect;
export type NewService = typeof services.$inferInsert;
export type Technician = typeof technicians.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type NewBooking = typeof bookings.$inferInsert;
export type Review = typeof reviews.$inferSelect;
export type NewReview = typeof reviews.$inferInsert;
export type GalleryItem = typeof galleryItems.$inferSelect;
export type Message = typeof messages.$inferSelect;
