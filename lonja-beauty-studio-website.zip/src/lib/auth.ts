import { cookies } from "next/headers";

export const ADMIN_COOKIE = "lonja_admin";

export function adminPasscode(): string {
  return process.env.ADMIN_PASSCODE ?? "lonja2026";
}

export async function isAdmin(): Promise<boolean> {
  const store = await cookies();
  return store.get(ADMIN_COOKIE)?.value === sessionToken();
}

export function sessionToken(): string {
  // Deterministic token derived from the passcode — good enough for a single
  // studio dashboard and requires no extra dependencies.
  const secret = adminPasscode();
  let hash = 5381;
  for (let i = 0; i < secret.length; i += 1) {
    hash = ((hash << 5) + hash + secret.charCodeAt(i)) & 0xffffffff;
  }
  return `lonja-${Math.abs(hash).toString(36)}`;
}
