import { and, asc, desc, eq, gte, inArray, ne, or, sql } from "drizzle-orm";

import { db } from "@/db";
import {
  bookings,
  galleryItems,
  messages,
  reviews,
  services,
  siteSettings,
  technicians,
  type Booking,
  type GalleryItem,
  type Review,
  type Service,
  type Technician,
} from "@/db/schema";
import { buildSlots, generateReference, normalizePhone, todayISO } from "./booking";
import { SEED_GALLERY, SEED_REVIEWS, SEED_TECHNICIANS } from "./seed-data";
import { SEED_SERVICES, slugify } from "./pricelist";

/* -------------------------------------------------------------------------- */
/*  Seeding                                                                   */
/* -------------------------------------------------------------------------- */

let seedPromise: Promise<void> | null = null;

async function runSeed(): Promise<void> {
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(services);

  if (Number(count) === 0) {
    await db.insert(services).values(
      SEED_SERVICES.map((service, index) => ({
        slug: slugify(`${service.name}-${service.category ?? "Hair"}`),
        name: service.name,
        category: service.category ?? "Hair",
        subcategory: service.subcategory ?? null,
        description: service.description ?? null,
        priceCents: service.priceCents,
        priceLabel: service.priceLabel ?? null,
        durationMinutes: service.durationMinutes ?? 60,
        isPopular: service.isPopular ?? false,
        sortOrder: index,
      })),
    ).onConflictDoNothing();
  }

  const [{ count: techCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(technicians);
  if (Number(techCount) === 0) {
    await db.insert(technicians).values(SEED_TECHNICIANS).onConflictDoNothing();
  }

  const [{ count: reviewCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(reviews);
  if (Number(reviewCount) === 0) {
    await db.insert(reviews).values(SEED_REVIEWS).onConflictDoNothing();
  }

  const [{ count: galleryCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(galleryItems);
  if (Number(galleryCount) === 0) {
    await db.insert(galleryItems).values(SEED_GALLERY).onConflictDoNothing();
  }

  await db
    .insert(siteSettings)
    .values([
      { key: "announcement", value: "Ladies Night every Thursday 4pm–8pm · bring a friend and you both get 10% off nails" },
      { key: "depositNotice", value: "No deposit needed for online bookings — we confirm by WhatsApp within business hours." },
    ])
    .onConflictDoNothing();
}

export async function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

/* -------------------------------------------------------------------------- */
/*  Services                                                                  */
/* -------------------------------------------------------------------------- */

export async function getServices(): Promise<Service[]> {
  await ensureSeeded();
  return db
    .select()
    .from(services)
    .where(eq(services.isActive, true))
    .orderBy(asc(services.sortOrder), asc(services.name));
}

export async function getBookableServices(): Promise<Service[]> {
  const all = await getServices();
  return all.filter((service) => service.durationMinutes <= 180);
}

export async function getPopularServices(limit = 6): Promise<Service[]> {
  const all = await getServices();
  const popular = all.filter((service) => service.isPopular);
  return (popular.length ? popular : all.slice(0, limit)).slice(0, limit);
}

export async function getServiceById(id: number): Promise<Service | null> {
  await ensureSeeded();
  const rows = await db.select().from(services).where(eq(services.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function searchServices(term: string): Promise<Service[]> {
  const all = await getServices();
  const q = term.trim().toLowerCase();
  if (!q) return all;
  return all.filter((service) =>
    `${service.name} ${service.category} ${service.subcategory ?? ""} ${service.description ?? ""}`
      .toLowerCase()
      .includes(q),
  );
}

/* -------------------------------------------------------------------------- */
/*  Team                                                                      */
/* -------------------------------------------------------------------------- */

export async function getTechnicians(): Promise<Technician[]> {
  await ensureSeeded();
  return db
    .select()
    .from(technicians)
    .where(eq(technicians.isActive, true))
    .orderBy(asc(technicians.sortOrder));
}

/* -------------------------------------------------------------------------- */
/*  Reviews                                                                   */
/* -------------------------------------------------------------------------- */

export async function getReviews(): Promise<Review[]> {
  await ensureSeeded();
  return db
    .select()
    .from(reviews)
    .where(eq(reviews.isApproved, true))
    .orderBy(desc(reviews.createdAt))
    .limit(60);
}

export async function getAllReviews(): Promise<Review[]> {
  await ensureSeeded();
  return db.select().from(reviews).orderBy(desc(reviews.createdAt)).limit(200);
}

export async function createReview(input: {
  authorName: string;
  rating: number;
  serviceTag?: string | null;
  technicianName?: string | null;
  body: string;
}): Promise<Review> {
  await ensureSeeded();
  const rows = await db
    .insert(reviews)
    .values({
      authorName: input.authorName,
      rating: input.rating,
      serviceTag: input.serviceTag ?? null,
      technicianName: input.technicianName ?? null,
      body: input.body,
      source: "website",
      isApproved: false,
      authorMeta: "Website review — awaiting approval",
    })
    .returning();
  return rows[0];
}

/* -------------------------------------------------------------------------- */
/*  Gallery                                                                   */
/* -------------------------------------------------------------------------- */

export async function getGallery(): Promise<GalleryItem[]> {
  await ensureSeeded();
  return db
    .select()
    .from(galleryItems)
    .orderBy(asc(galleryItems.sortOrder), desc(galleryItems.createdAt));
}

/* -------------------------------------------------------------------------- */
/*  Availability + bookings                                                   */
/* -------------------------------------------------------------------------- */

async function takenCountsFor(dateISO: string): Promise<Record<string, number>> {
  const rows = await db
    .select({
      time: bookings.bookingTime,
      count: sql<number>`count(*)::int`,
    })
    .from(bookings)
    .where(
      and(
        eq(bookings.bookingDate, dateISO),
        ne(bookings.status, "cancelled"),
        ne(bookings.status, "no_show"),
      ),
    )
    .groupBy(bookings.bookingTime);

  const map: Record<string, number> = {};
  for (const row of rows) map[row.time] = Number(row.count);
  return map;
}

export async function getAvailability(dateISO: string, durationMinutes: number) {
  const counts = await takenCountsFor(dateISO);
  return buildSlots(dateISO, durationMinutes, counts);
}

export async function getBusySlots(dateISO: string) {
  return takenCountsFor(dateISO);
}

export type BookingInput = {
  customerName: string;
  customerPhone: string;
  customerEmail?: string | null;
  serviceId: number;
  addOns?: { name: string; priceCents: number }[];
  technicianId?: number | null;
  bookingDate: string;
  bookingTime: string;
  notes?: string | null;
};

export class BookingError extends Error {}

export async function createBooking(input: BookingInput): Promise<Booking> {
  await ensureSeeded();

  const service = await getServiceById(input.serviceId);
  if (!service) throw new BookingError("That service is no longer available.");

  const counts = await takenCountsFor(input.bookingDate);
  const slots = buildSlots(input.bookingDate, service.durationMinutes, counts);
  const slot = slots.find((option) => option.time === input.bookingTime);

  if (!slot) throw new BookingError("That time is outside our trading hours.");
  if (!slot.available) {
    throw new BookingError(
      slot.reason ?? "That time has just been taken. Please pick another slot.",
    );
  }

  const addOns = (input.addOns ?? []).filter((item) => item && item.name);
  const addOnTotal = addOns.reduce((sum, item) => sum + item.priceCents, 0);

  let technicianName: string | null = null;
  if (input.technicianId) {
    const rows = await db
      .select()
      .from(technicians)
      .where(eq(technicians.id, input.technicianId))
      .limit(1);
    technicianName = rows[0]?.name ?? null;
  }

  const rows = await db
    .insert(bookings)
    .values({
      reference: generateReference(),
      customerName: input.customerName,
      customerPhone: normalizePhone(input.customerPhone),
      customerEmail: input.customerEmail ?? null,
      serviceId: service.id,
      serviceName: service.name,
      serviceCategory: service.category,
      addOns,
      technicianId: technicianName ? input.technicianId ?? null : null,
      technicianName,
      bookingDate: input.bookingDate,
      bookingTime: input.bookingTime,
      durationMinutes: service.durationMinutes,
      totalCents: service.priceCents + addOnTotal,
      notes: input.notes ?? null,
      status: "pending",
    })
    .returning();

  return rows[0];
}

export async function getBookingByReference(reference: string): Promise<Booking | null> {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(bookings)
    .where(eq(bookings.reference, reference.trim().toUpperCase()))
    .limit(1);
  return rows[0] ?? null;
}

export async function findBookingsByPhone(phone: string): Promise<Booking[]> {
  await ensureSeeded();
  const normalised = normalizePhone(phone);
  return db
    .select()
    .from(bookings)
    .where(
      or(
        eq(bookings.customerPhone, normalised),
        eq(bookings.customerPhone, phone.trim()),
      ),
    )
    .orderBy(desc(bookings.bookingDate))
    .limit(25);
}

export async function getUpcomingBookings(limit = 20): Promise<Booking[]> {
  await ensureSeeded();
  const iso = todayISO();
  return db
    .select()
    .from(bookings)
    .where(
      and(
        gte(bookings.bookingDate, iso),
        or(eq(bookings.status, "pending"), eq(bookings.status, "confirmed")),
      ),
    )
    .orderBy(asc(bookings.bookingDate), asc(bookings.bookingTime))
    .limit(limit);
}

export async function getBookingsByDate(dateISO: string): Promise<Booking[]> {
  await ensureSeeded();
  return db
    .select()
    .from(bookings)
    .where(eq(bookings.bookingDate, dateISO))
    .orderBy(asc(bookings.bookingTime));
}

export async function getAllBookings(status?: string): Promise<Booking[]> {
  await ensureSeeded();
  const query = db.select().from(bookings);
  const rows = status
    ? await query.where(eq(bookings.status, status)).orderBy(desc(bookings.createdAt)).limit(200)
    : await query.orderBy(desc(bookings.createdAt)).limit(200);
  return rows;
}

export async function updateBookingStatus(id: number, status: string) {
  const rows = await db
    .update(bookings)
    .set({ status, updatedAt: new Date() })
    .where(eq(bookings.id, id))
    .returning();
  return rows[0] ?? null;
}

export async function deleteBooking(id: number) {
  await db.delete(bookings).where(eq(bookings.id, id));
}

/* -------------------------------------------------------------------------- */
/*  Messages + settings                                                       */
/* -------------------------------------------------------------------------- */

export async function createMessage(input: {
  name: string;
  phone?: string | null;
  email?: string | null;
  subject?: string | null;
  body: string;
}) {
  const rows = await db.insert(messages).values(input).returning();
  return rows[0];
}

export async function getMessages() {
  await ensureSeeded();
  return db.select().from(messages).orderBy(desc(messages.createdAt)).limit(100);
}

export async function markMessageRead(id: number) {
  await db.update(messages).set({ isRead: true }).where(eq(messages.id, id));
}

export async function getSetting(key: string, fallback = ""): Promise<string> {
  try {
    await ensureSeeded();
    const rows = await db
      .select()
      .from(siteSettings)
      .where(eq(siteSettings.key, key))
      .limit(1);
    return rows[0]?.value ?? fallback;
  } catch {
    return fallback;
  }
}

export async function setSetting(key: string, value: string) {
  await db
    .insert(siteSettings)
    .values({ key, value })
    .onConflictDoUpdate({
      target: siteSettings.key,
      set: { value, updatedAt: new Date() },
    });
}

/* -------------------------------------------------------------------------- */
/*  Aggregate stats for the dashboard                                         */
/* -------------------------------------------------------------------------- */

export async function getDashboardStats() {
  await ensureSeeded();
  const rows = await db
    .select({
      status: bookings.status,
      count: sql<number>`count(*)::int`,
      revenue: sql<number>`coalesce(sum(${bookings.totalCents}), 0)::int`,
    })
    .from(bookings)
    .groupBy(bookings.status);

  const stats = {
    total: 0,
    pending: 0,
    confirmed: 0,
    completed: 0,
    cancelled: 0,
    revenueCents: 0,
  };

  for (const row of rows) {
    const count = Number(row.count);
    stats.total += count;
    if (row.status in stats) {
      (stats as unknown as Record<string, number>)[row.status] = count;
    }
    if (row.status === "completed" || row.status === "confirmed") {
      stats.revenueCents += Number(row.revenue);
    }
  }

  return stats;
}

export async function getServicesByIds(ids: number[]): Promise<Service[]> {
  if (!ids.length) return [];
  await ensureSeeded();
  return db.select().from(services).where(inArray(services.id, ids));
}
