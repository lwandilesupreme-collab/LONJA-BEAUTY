import { SITE } from "./site";

/** How many clients can be served at the same start time (stations on the floor). */
export const STATIONS_PER_SLOT = 4;

/** Minimum notice for a same-day online booking. */
export const LEAD_TIME_MINUTES = 60;

/** How far ahead clients may book. */
export const BOOKING_WINDOW_DAYS = 60;

export const SLOT_STEP_MINUTES = 30;

export const BOOKING_STATUSES = [
  "pending",
  "confirmed",
  "completed",
  "cancelled",
  "no_show",
] as const;

export type BookingStatus = (typeof BOOKING_STATUSES)[number];

export const STATUS_LABEL: Record<string, string> = {
  pending: "Pending confirmation",
  confirmed: "Confirmed",
  completed: "Completed",
  cancelled: "Cancelled",
  no_show: "No show",
};

export const STATUS_STYLE: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800 ring-amber-200",
  confirmed: "bg-emerald-100 text-emerald-800 ring-emerald-200",
  completed: "bg-stone-200 text-stone-700 ring-stone-300",
  cancelled: "bg-rose-100 text-rose-700 ring-rose-200",
  no_show: "bg-rose-100 text-rose-700 ring-rose-200",
};

/** "09:00" -> minutes since midnight */
export function timeToMinutes(time: string): number {
  const [h, m] = time.split(":").map(Number);
  return h * 60 + (m || 0);
}

/** minutes since midnight -> "09:30" */
export function minutesToTime(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

/** 09:00 -> "9:00 am" */
export function prettyTime(time: string): string {
  const [h, m] = time.split(":").map(Number);
  const suffix = h >= 12 ? "pm" : "am";
  const hour = h % 12 === 0 ? 12 : h % 12;
  return `${hour}:${String(m).padStart(2, "0")} ${suffix}`;
}

export function isOpenOn(dateISO: string): boolean {
  const day = new Date(`${dateISO}T00:00:00`).getDay(); // 0 = Sunday
  const index = day === 0 ? 6 : day - 1;
  return Boolean(SITE.hours[index]);
}

export function hoursFor(dateISO: string): { open: string; close: string } {
  const day = new Date(`${dateISO}T00:00:00`).getDay();
  const index = day === 0 ? 6 : day - 1;
  const entry = SITE.hours[index];
  return { open: entry?.open ?? "09:00", close: entry?.close ?? "18:00" };
}

export function todayISO(): string {
  const now = new Date();
  return toISODate(now);
}

export function toISODate(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function addDaysISO(iso: string, days: number): string {
  const d = new Date(`${iso}T00:00:00`);
  d.setDate(d.getDate() + days);
  return toISODate(d);
}

export function isValidISODate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = new Date(`${value}T00:00:00`);
  return !Number.isNaN(d.getTime());
}

export function prettyDate(iso: string): string {
  const d = new Date(`${iso}T00:00:00`);
  return d.toLocaleDateString("en-ZA", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export function shortDate(iso: string): string {
  const d = new Date(`${iso}T00:00:00`);
  return d.toLocaleDateString("en-ZA", {
    weekday: "short",
    day: "numeric",
    month: "short",
  });
}

export type SlotOption = {
  time: string;
  label: string;
  available: boolean;
  reason?: string;
  remaining: number;
};

/**
 * Build the bookable slot list for a date, given how many bookings already
 * start at each slot.
 */
export function buildSlots(
  dateISO: string,
  durationMinutes: number,
  takenCounts: Record<string, number>,
): SlotOption[] {
  const { open, close } = hoursFor(dateISO);
  const openMin = timeToMinutes(open);
  const closeMin = timeToMinutes(close);
  const slots: SlotOption[] = [];

  const now = new Date();
  const isToday = dateISO === todayISO();
  const cutoff = now.getTime() + LEAD_TIME_MINUTES * 60_000;

  for (let m = openMin; m + Math.min(durationMinutes, 180) <= closeMin; m += SLOT_STEP_MINUTES) {
    const time = minutesToTime(m);
    const remaining = Math.max(0, STATIONS_PER_SLOT - (takenCounts[time] ?? 0));
    let available = remaining > 0;
    let reason: string | undefined;

    if (!available) {
      reason = "Fully booked";
    }

    if (available && isToday) {
      const slotDate = new Date(`${dateISO}T${time}:00`);
      if (slotDate.getTime() < cutoff) {
        available = false;
        reason = "Too soon — please call us";
      }
    }

    slots.push({
      time,
      label: prettyTime(time),
      available,
      reason,
      remaining,
    });
  }

  return slots;
}

const REF_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function generateReference(): string {
  let out = "";
  for (let i = 0; i < 6; i += 1) {
    out += REF_ALPHABET[Math.floor(Math.random() * REF_ALPHABET.length)];
  }
  return `LB-${out}`;
}

/** Normalise a SA phone number for storage/matching. */
export function normalizePhone(raw: string): string {
  const digits = raw.replace(/[^\d+]/g, "");
  return digits.startsWith("0") ? `+27${digits.slice(1)}` : digits;
}
