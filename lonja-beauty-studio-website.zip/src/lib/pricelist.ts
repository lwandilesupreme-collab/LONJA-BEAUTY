/**
 * The complete Lonja Beauty Studio pricelist, used to seed the database and as
 * a fallback if the database has not been seeded yet.
 */

export type SeedService = {
  name: string;
  category?: string;
  subcategory?: string;
  priceCents: number;
  priceLabel?: string;
  durationMinutes?: number;
  description?: string;
  isPopular?: boolean;
};

export const CATEGORIES = [
  "Nails",
  "Eyelashes",
  "Hair",
  "Hair Cuts",
  "Kids",
] as const;

export const CATEGORY_META: Record<
  string,
  { label: string; icon: string; blurb: string }
> = {
  Nails: {
    label: "Nails",
    icon: "💅",
    blurb:
      "Acrylic, gel, polygel, cat eye, ombre and hand-painted art by our senior nail techs.",
  },
  Eyelashes: {
    label: "Eyelashes",
    icon: "👁️",
    blurb:
      "Clusters to mega volume, plus brow tinting and shaping for a full face finish.",
  },
  Hair: {
    label: "Hair",
    icon: "💇🏽‍♀️",
    blurb:
      "Braids, relaxers, blow outs, installs, wigs and treatments for every hair type.",
  },
  "Hair Cuts": {
    label: "Hair Cuts",
    icon: "✂️",
    blurb: "Sharp fades, chiskops, waves, popcorns and full cut-and-style packages.",
  },
  Kids: {
    label: "Kids",
    icon: "👧",
    blurb: "Gentle, patient styling for the little ones — braids, up dos and relaxers.",
  },
};

const NAILS: SeedService[] = [
  { name: "Acrylic Tips", priceCents: 19000, durationMinutes: 90, isPopular: true, description: "Classic acrylic tip extensions, shaped and finished with your choice of colour." },
  { name: "Acrylic & Gel Tips", priceCents: 28000, durationMinutes: 105, isPopular: true, description: "Acrylic structure sealed with a high-shine gel overlay for extra durability." },
  { name: "Gel Hands", priceCents: 15000, durationMinutes: 60, description: "Gel polish on natural nails, cured for a chip-free two-week+ wear." },
  { name: "Gel Toes", priceCents: 15000, durationMinutes: 60, description: "Long-lasting gel colour on toenails with a tidy cuticle tidy-up." },
  { name: "Polygel", priceCents: 38000, durationMinutes: 120, description: "Lightweight polygel extensions — stronger than gel, lighter than acrylic." },
  { name: "Polygel French", priceCents: 45000, durationMinutes: 135, description: "Polygel extensions finished with a crisp hand-painted French line." },
  { name: "French Gel", priceCents: 25000, durationMinutes: 75, description: "Gel colour with a timeless white tip on your natural nail length." },
  { name: "Ombre Nails", priceCents: 42000, durationMinutes: 120, isPopular: true, description: "Seamless airbrushed gradient from nude to colour, finished glossy." },
  { name: "French", priceCents: 35000, durationMinutes: 105, description: "Full acrylic set with a classic French tip application." },
  { name: "Double French", priceCents: 38000, durationMinutes: 120, description: "Two-tone double line French for a modern take on the classic." },
  { name: "Cat Eye", priceCents: 48000, durationMinutes: 120, isPopular: true, description: "Magnetic gel with a metallic light streak that shifts in the light." },
  { name: "Cat Eye French", priceCents: 56000, durationMinutes: 135, description: "Cat eye gel paired with a French tip — our most requested luxury set." },
  { name: "Acrylic Soak-Off", priceCents: 8000, durationMinutes: 30, description: "Safe removal of an existing acrylic set, includes nail prep." },
  { name: "Gel Soak-Off", priceCents: 5000, durationMinutes: 30, description: "Gentle gel polish removal with cuticle oil finish." },
  { name: "Acrylic Refill", priceCents: 17000, durationMinutes: 75, description: "Infill and rebalance for a 2–3 week old acrylic set." },
  { name: "Gel on Acrylic Refill", priceCents: 23000, durationMinutes: 90, description: "Acrylic infill finished with a gel colour overlay." },
  { name: "French Refill", priceCents: 25000, durationMinutes: 90, description: "Acrylic infill with a fresh French tip." },
  { name: "Art (per nail)", priceCents: 1500, durationMinutes: 10, description: "Hand-painted art per nail — stripes, dots, marble, lines." },
  { name: "3D Art (per nail)", priceCents: 2500, durationMinutes: 15, description: "Sculpted 3D detail per nail — bows, charms, raised design." },
  { name: "3D Flower", priceCents: 3000, durationMinutes: 15, description: "Sculpted 3D flower per nail, built from acrylic." },
  { name: "Chrome (per nail)", priceCents: 2000, durationMinutes: 10, description: "Mirror chrome pigment per nail — silver, gold, rose or custom." },
  { name: "Buff & Shine", priceCents: 13000, durationMinutes: 45, description: "Natural nail buff, cuticle care and a high-green shine — no polish." },
  { name: "Foot Scrub", priceCents: 20000, durationMinutes: 45, description: "Exfoliating foot scrub and moisturising massage." },
];

const LASHES: SeedService[] = [
  { name: "Clusters", priceCents: 23000, durationMinutes: 60, description: "Cluster lash application for a quick, fuller look." },
  { name: "Classic", priceCents: 25000, durationMinutes: 90, description: "One extension per natural lash for a soft, everyday lift." },
  { name: "Hybrid", priceCents: 34000, durationMinutes: 105, isPopular: true, description: "Mix of classic and volume lashes for texture and fullness." },
  { name: "Volume", priceCents: 42000, durationMinutes: 120, description: "Hand-made fans for a dramatic, fluffy lash line." },
  { name: "Mega Volume", priceCents: 48000, durationMinutes: 135, description: "Maximum density mega volume set — the full glam look." },
  { name: "Cat Eye Lashes", priceCents: 33000, durationMinutes: 90, description: "Winged lash mapping that lifts and elongates the eye." },
  { name: "Lash Removal", priceCents: 10000, durationMinutes: 30, description: "Safe, professional removal of existing lash extensions." },
  { name: "Eyebrow Tint & Shape", priceCents: 14000, durationMinutes: 45, description: "Tint, map and shape for defined, low-maintenance brows." },
];

const HAIR: SeedService[] = [
  { name: "Wash", subcategory: "General", priceCents: 10000, durationMinutes: 30 },
  { name: "Treatment", subcategory: "General", priceCents: 25000, durationMinutes: 60, description: "Deep conditioning treatment with steam." },
  { name: "Hair Mayonnaise Treatment", subcategory: "General", priceCents: 25000, durationMinutes: 60 },
  { name: "Hair Dye", subcategory: "General", priceCents: 25000, durationMinutes: 90 },
  { name: "Hair Bleach", subcategory: "General", priceCents: 35000, durationMinutes: 120 },
  { name: "Blow Out", subcategory: "General", priceCents: 25000, durationMinutes: 60, isPopular: true },
  { name: "Highlights", subcategory: "General", priceCents: 25000, durationMinutes: 120 },
  { name: "Sew-In (excluding hairpiece)", subcategory: "General", priceCents: 45000, durationMinutes: 180 },
  { name: "Soft n Free Relaxer", subcategory: "Relaxer & Styling", priceCents: 25000, durationMinutes: 90 },
  { name: "Dark n Lovely Relaxer", subcategory: "Relaxer & Styling", priceCents: 28000, durationMinutes: 90 },
  { name: "Wig Lines", subcategory: "Relaxer & Styling", priceCents: 15000, durationMinutes: 45 },
  { name: "Freehand", subcategory: "Relaxer & Styling", priceCents: 25000, durationMinutes: 60 },
  { name: "Straight Back", subcategory: "Relaxer & Styling", priceCents: 25000, durationMinutes: 90, isPopular: true },
  { name: "Straight Back with Curls", subcategory: "Relaxer & Styling", priceCents: 35000, durationMinutes: 120 },
  { name: "Straight Up", subcategory: "Relaxer & Styling", priceCents: 45000, priceLabel: "Starts @ R450", durationMinutes: 150 },
  { name: "Knotless Braids — Short", subcategory: "Knotless Braids", priceCents: 75000, durationMinutes: 240, isPopular: true },
  { name: "Knotless Braids — Bra Length", subcategory: "Knotless Braids", priceCents: 85000, durationMinutes: 300 },
  { name: "Knotless Braids — Waist Length", subcategory: "Knotless Braids", priceCents: 95000, durationMinutes: 360, description: "Top up R100 to add curls." },
  { name: "Tribal Braids — Short", subcategory: "Tribal Braids", priceCents: 55000, durationMinutes: 240 },
  { name: "Tribal Braids — Bra Length", subcategory: "Tribal Braids", priceCents: 65000, durationMinutes: 300 },
  { name: "Tribal Braids — Waist Length", subcategory: "Tribal Braids", priceCents: 75000, durationMinutes: 330 },
  { name: "Basic Installation", subcategory: "Installs & Wigs", priceCents: 28000, durationMinutes: 120 },
  { name: "Installation (excluding wig lines)", subcategory: "Installs & Wigs", priceCents: 35000, durationMinutes: 150 },
  { name: "Wig Styling", subcategory: "Installs & Wigs", priceCents: 15000, priceLabel: "From R150", durationMinutes: 60, description: "Priced according to length." },
  { name: "Wig Wash", subcategory: "Installs & Wigs", priceCents: 25000, durationMinutes: 60 },
  { name: "Wig Making (with own hair)", subcategory: "Installs & Wigs", priceCents: 50000, durationMinutes: 240 },
  { name: "Wig Colouring", subcategory: "Installs & Wigs", priceCents: 35000, durationMinutes: 150 },
  { name: "Wash, Blow Dry & Straighten", subcategory: "Caucasian Hair", priceCents: 25000, durationMinutes: 90 },
  { name: "Needle Plait", subcategory: "Caucasian Hair", priceCents: 23000, durationMinutes: 120 },
  { name: "Stitched Cornrows", subcategory: "Caucasian Hair", priceCents: 35000, durationMinutes: 120 },
  { name: "Dreadlocks (twist | wash | style)", subcategory: "Caucasian Hair", priceCents: 45000, durationMinutes: 150 },
];

const CUTS: SeedService[] = [
  { name: "Chiskop", priceCents: 8000, durationMinutes: 30 },
  { name: "Cut & Paste", priceCents: 55000, durationMinutes: 90 },
  { name: "Fade", priceCents: 12000, durationMinutes: 45, isPopular: true },
  { name: "Cut & Style", priceCents: 30000, durationMinutes: 60 },
  { name: "Cut | Style | Relax", priceCents: 45000, durationMinutes: 120 },
  { name: "Waves (styling only)", priceCents: 25000, durationMinutes: 45 },
  { name: "Waves & Relax", priceCents: 60000, durationMinutes: 120 },
  { name: "Dye", priceCents: 25000, durationMinutes: 90 },
  { name: "Popcorn", priceCents: 40000, durationMinutes: 90 },
  { name: "Dry Curl", priceCents: 40000, durationMinutes: 90 },
];

const KIDS: SeedService[] = [
  { name: "Freshhead", priceCents: 25000, durationMinutes: 60 },
  { name: "Up Do", priceCents: 30000, durationMinutes: 60 },
  { name: "Braids", priceCents: 45000, durationMinutes: 150 },
  { name: "Relaxer", priceCents: 25000, durationMinutes: 90 },
  { name: "Fish Bone", priceCents: 28000, durationMinutes: 120 },
  { name: "Needle Plaiting", priceCents: 28000, durationMinutes: 120 },
  { name: "Kids Braids (small)", priceCents: 5000, priceLabel: "From R50", durationMinutes: 45 },
];

export const SEED_SERVICES: SeedService[] = [
  ...NAILS.map((s) => ({ ...s, category: "Nails" as const })),
  ...LASHES.map((s) => ({ ...s, category: "Eyelashes" as const })),
  ...HAIR.map((s) => ({ ...s, category: "Hair" as const })),
  ...CUTS.map((s) => ({ ...s, category: "Hair Cuts" as const })),
  ...KIDS.map((s) => ({ ...s, category: "Kids" as const })),
];

export const CATEGORY_ORDER = ["Nails", "Eyelashes", "Hair", "Hair Cuts", "Kids"];

/** Services that can be booked online (kept focused so the calendar stays sane). */
export const BOOKABLE_CATEGORIES = ["Nails", "Eyelashes"];

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 120);
}
