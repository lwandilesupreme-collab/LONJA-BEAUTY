/**
 * Supabase connectivity helpers.
 *
 * This app talks to Postgres through Drizzle (`@/db`), which means it works
 * out of the box with a local Postgres *and* with Supabase — you only need to
 * point `DATABASE_URL` at your Supabase connection string (Project settings →
 * Database → Connection string → URI, or the connection pooler URI on
 * port 6543 for serverless).
 *
 * Optional env vars:
 *   DATABASE_URL              – Postgres/Supabase connection string (required)
 *   NEXT_PUBLIC_SUPABASE_URL  – project URL, enables Storage-backed gallery
 *   SUPABASE_SERVICE_ROLE_KEY – server-only key for privileged Storage access
 */

export function getSupabaseProjectUrl(): string | null {
  return process.env.NEXT_PUBLIC_SUPABASE_URL ?? null;
}

export function isSupabaseConfigured(): boolean {
  return Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY,
  );
}

/** Resolve a gallery image URL that may be a bare Supabase Storage path. */
export function resolveMediaUrl(url: string): string {
  if (!url) return "/images/gallery-1.jpg";
  if (/^https?:\/\//i.test(url)) return url;
  if (url.startsWith("/")) return url;
  const projectUrl = getSupabaseProjectUrl();
  if (projectUrl) {
    return `${projectUrl.replace(/\/$/, "")}/storage/v1/object/public/gallery/${url}`;
  }
  return `/${url}`;
}

/** Mask a connection string so it is safe to render in an admin diagnostics view. */
export function maskDatabaseUrl(url: string | undefined): string {
  if (!url) return "not configured";
  try {
    const parsed = new URL(url);
    const host = parsed.host;
    const database = parsed.pathname.replace(/^\//, "");
    return `postgresql://${parsed.username || "user"}:••••@${host}/${database}`;
  } catch {
    return "configured";
  }
}
