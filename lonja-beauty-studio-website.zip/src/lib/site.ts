export const SITE = {
  name: "Lonja Beauty Studio",
  branch: "Fourways",
  fullName: "Lonja Beauty Studio Fourways",
  tagline: "Nails, lashes & hair — done beautifully.",
  description:
    "Lonja Beauty Studio Fourways is your go-to nail tech and beauty studio in Fourways, Johannesburg. Acrylics, gel, polygel, cat eye, lashes, braids and blow outs, seven days a week.",
  phoneDisplay: "073 086 6933",
  phoneTel: "+27730866933",
  whatsapp: "27730866933",
  email: "hello@lonjabeauty.co.za",
  address: {
    street: "264 Pritchard St",
    area: "Fourways",
    city: "Johannesburg",
    code: "2196",
    full: "264 Pritchard St, Fourways, Johannesburg, 2196",
  },
  plusCode: "XXCF+9V Fourways, Sandton",
  mapsQuery:
    "Lonja+Beauty+Studio+Fourways+264+Pritchard+St,+Fourways,+Johannesburg,+2196",
  mapsDirections:
    "https://www.google.com/maps/dir/?api=1&destination=264+Pritchard+St,+Fourways,+Johannesburg,+2196",
  mapsEmbed:
    "https://www.google.com/maps?q=264%20Pritchard%20St%2C%20Fourways%2C%20Johannesburg%2C%202196&output=embed",
  rating: 3.2,
  reviewCount: 181,
  hours: [
    { day: "Monday", open: "09:00", close: "18:00" },
    { day: "Tuesday", open: "09:00", close: "18:00" },
    { day: "Wednesday", open: "09:00", close: "18:00" },
    { day: "Thursday", open: "09:00", close: "18:00" },
    { day: "Friday", open: "09:00", close: "18:00" },
    { day: "Saturday", open: "09:00", close: "18:00" },
    { day: "Sunday", open: "09:00", close: "18:00" },
  ],
  socials: [
    { label: "Instagram", href: "https://instagram.com", handle: "@lonjabeauty" },
    { label: "Facebook", href: "https://facebook.com", handle: "Lonja Beauty Studio" },
    { label: "TikTok", href: "https://tiktok.com", handle: "@lonjabeauty" },
  ],
} as const;

export function formatMoney(cents: number): string {
  return `R${(cents / 100).toLocaleString("en-ZA", {
    minimumFractionDigits: cents % 100 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  })}`;
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} min`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m === 0 ? `${h} hr${h > 1 ? "s" : ""}` : `${h}h ${m}m`;
}

export function whatsappLink(message: string): string {
  return `https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(message)}`;
}
