# Lonja Beauty Studio Fourways

A full-stack website for **Lonja Beauty Studio**, a nail tech & beauty studio at
264 Pritchard St, Fourways, Johannesburg, 2196.

Built with **Next.js (App Router)**, **Tailwind CSS v4**, **Drizzle ORM** and **PostgreSQL**.

## What's inside

| Area | Route | Notes |
| --- | --- | --- |
| Home | `/` | Hero, popular services, gallery preview, reviews, map + hours |
| Full pricelist | `/services` | Searchable + category filter, grouped by sub-category, live from the DB |
| Online booking | `/book` | 4-step wizard: service → date & time → details → confirmation |
| Booking lookup | `/track` | Find a booking by `LB-XXXXXX` reference or phone number |
| Gallery | `/gallery` | Filterable portfolio grid |
| Team | `/team` | Nail tech profiles + Google review shout-outs |
| Reviews | `/reviews` | Rating breakdown, all reviews, moderated submission form |
| Contact | `/contact` | Address, hours, map embed, FAQ, contact form → DB |
| Studio admin | `/admin` | Passcode-gated dashboard: bookings, statuses, review moderation, messages |

### API routes

- `GET  /api/health` — health probe
- `GET  /api/bookings?date=YYYY-MM-DD&serviceId=1` — live slot availability
- `POST /api/bookings` — create a booking (validates + re-checks availability server-side)
- `GET  /api/bookings/lookup?reference=LB-XXXX` or `?phone=073...`
- `POST /api/reviews` — submit a review (held for moderation)
- `POST /api/messages` — contact form
- `POST /api/admin/login` / `DELETE /api/admin/login` — admin session cookie
- `PATCH|DELETE /api/admin/bookings/[id]` — update booking status
- `PATCH|DELETE /api/admin/reviews/[id]` — approve / reject reviews

## Admin access

Visit `/admin` and use the passcode from `ADMIN_PASSCODE` (default `lonja2026`).

## Connecting to Supabase

The app talks to Postgres **only** through Drizzle (`src/db/index.ts`), so pointing it at
Supabase is a connection-string swap:

1. Create a Supabase project.
2. Copy **Project settings → Database → Connection string → URI** (use the **connection
   pooler** URI on port `6543` for serverless deployments).
3. Set it in your environment:
   ```bash
   DATABASE_URL="postgresql://postgres.[ref]:[password]@aws-0-[region].pooler.supabase.com:6543/postgres"
   ```
4. Push the schema:
   ```bash
   npx drizzle-kit push
   ```
5. Restart. On the first request the app **auto-seeds** the pricelist, team, gallery and the
   imported Google reviews (idempotent — it only seeds empty tables).

### Optional: Supabase Storage for gallery images

Set `NEXT_PUBLIC_SUPABASE_URL` (and `SUPABASE_SERVICE_ROLE_KEY` for server-side uploads) and
gallery rows whose `image_url` is a bare filename will resolve to
`https://<ref>.supabase.co/storage/v1/object/public/gallery/<file>` via `resolveMediaUrl()`
in `src/lib/supabase.ts`. Create a **public** storage bucket named `gallery`.

## Booking rules (`src/lib/booking.ts`)

- Open 09:00–18:00, seven days a week, 30-minute slots.
- 4 concurrent chairs (`STATIONS_PER_SLOT`) — a slot disappears once full.
- Same-day online bookings need 60 minutes' notice.
- Bookings look up to 60 days ahead.
- Soak-offs, art, chrome and foot scrub are offered as add-ons priced off the real menu.

## Local development

```bash
npm install
npx drizzle-kit push
npm run dev
```
